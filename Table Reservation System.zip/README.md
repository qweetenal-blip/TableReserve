
  # Table Reservation System

  This is a code bundle for Table Reservation System. The original project is available at https://www.figma.com/design/5VOIMG6j1sblqWxTE0Tdh8/Table-Reservation-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  