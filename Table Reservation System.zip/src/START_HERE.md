# 🚀 НАЧНИТЕ ЗДЕСЬ - TableReserve

## ⚡ Быстрый старт за 30 секунд

### 1️⃣ Откройте проект
Проект уже запущен в Figma Make. Просто откройте его в браузере.

### 2️⃣ Проверьте готовность (F12 → Console)
```javascript
console.log('✅ Система готова:', localStorage.getItem('tablereserve_initialized') === 'true');
```

### 3️⃣ Войдите как администратор
```
Email: admin@tablereserve.ru
Пароль: admin123
```

### 4️⃣ Откройте админ-панель
Нажмите на иконку щита 🛡️ в правом верхнем углу

---

## 🎯 Что проверить за 2 минуты

### ✅ Шаг 1: Каталог (30 сек)
1. Главная страница → кнопка "Выбрать ресторан"
2. Видите 6 ресторанов
3. Поиск работает
4. Фильтр по кухне работает

### ✅ Шаг 2: Бронирование (1 мин)
1. Выберите любой ресторан
2. Нажмите "Забронировать"
3. Заполните форму (дата, время, гости)
4. Подтвердите
5. Видите сообщение об успехе

### ✅ Шаг 3: Админ-панель (30 сек)
1. Войдите как админ (admin@tablereserve.ru / admin123)
2. Нажмите иконку щита 🛡️
3. Посмотрите статистику
4. Вкладка "Бронирования" → подтвердите любое
5. Вкладка "Отзывы" → удалите любой

---

## 💻 Полная проверка через консоль

Скопируйте и выполните в консоли (F12):

```javascript
// ========================================
// АВТОМАТИЧЕСКАЯ ПРОВЕРКА TABLERESERVE
// ========================================

console.log('🔍 Начало проверки системы...\n');

// 1. Проверка инициализации
const isInitialized = localStorage.getItem('tablereserve_initialized') === 'true';
console.log(isInitialized ? '✅' : '❌', 'База данных инициализирована:', isInitialized);

// 2. Проверка данных
const users = JSON.parse(localStorage.getItem('tablereserve_users') || '[]');
const restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants') || '[]');
const bookings = JSON.parse(localStorage.getItem('tablereserve_bookings') || '[]');
const feedbacks = JSON.parse(localStorage.getItem('tablereserve_feedbacks') || '[]');

console.log(users.length >= 2 ? '✅' : '❌', `Пользователей: ${users.length} (ожидается ≥2)`);
console.log(restaurants.length >= 6 ? '✅' : '❌', `Ресторанов: ${restaurants.length} (ожидается ≥6)`);
console.log(bookings.length >= 2 ? '✅' : '❌', `Бронирований: ${bookings.length} (ожидается ≥2)`);
console.log(feedbacks.length >= 2 ? '✅' : '❌', `Отзывов: ${feedbacks.length} (ожидается ≥2)`);

// 3. Проверка учетных записей
const adminExists = users.some(u => u.email === 'admin@tablereserve.ru' && u.isAdmin);
const userExists = users.some(u => u.email === 'user@example.com' && !u.isAdmin);

console.log(adminExists ? '✅' : '❌', 'Аккаунт администратора существует');
console.log(userExists ? '✅' : '❌', 'Аккаунт пользователя существует');

// 4. Вывод статистики
console.log('\n📊 Детальная статистика:');
console.table({
  'Всего пользователей': users.length,
  'Администраторов': users.filter(u => u.isAdmin).length,
  'Обычных пользователей': users.filter(u => !u.isAdmin).length,
  'Всего ресторанов': restaurants.length,
  'Всего бронирований': bookings.length,
  'Подтверждено': bookings.filter(b => b.status === 'confirmed').length,
  'Ожидает': bookings.filter(b => b.status === 'created').length,
  'Отменено': bookings.filter(b => b.status === 'cancelled').length,
  'Всего отзывов': feedbacks.length
});

// 5. Итоговая оценка
const totalChecks = 7;
const passedChecks = [
  isInitialized,
  users.length >= 2,
  restaurants.length >= 6,
  bookings.length >= 2,
  feedbacks.length >= 2,
  adminExists,
  userExists
].filter(Boolean).length;

const percentage = Math.round((passedChecks / totalChecks) * 100);

console.log(`\n🎯 Результат проверки: ${passedChecks}/${totalChecks} (${percentage}%)`);

if (percentage === 100) {
  console.log('✅ ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ! Система полностью готова к работе.');
} else if (percentage >= 70) {
  console.log('⚠️ Система работает, но есть небольшие проблемы.');
} else {
  console.log('❌ Обнаружены критические проблемы. Требуется переинициализация.');
  console.log('Выполните: localStorage.clear(); location.reload();');
}

console.log('\n✨ Проверка завершена!');
```

---

## 🔑 Тестовые аккаунты

### Администратор (полный доступ)
```
Email: admin@tablereserve.ru
Пароль: admin123
```
**Возможности:**
- ✅ Управление ресторанами
- ✅ Модерация бронирований
- ✅ Удаление отзывов
- ✅ Управление пользователями
- ✅ Просмотр аналитики

### Обычный пользователь
```
Email: user@example.com
Пароль: user123
```
**Возможности:**
- ✅ Бронирование столов
- ✅ Управление своими бронированиями
- ✅ Оставление отзывов

---

## 📚 Документация

Выберите нужный документ:

| Файл | Описание | Когда использовать |
|------|----------|-------------------|
| **START_HERE.md** | Этот файл - быстрый старт | Первый запуск |
| **LAUNCH_INSTRUCTIONS.md** | Краткая инструкция для проверяющего | Сдача проекта |
| **QUICK_START_CODE.md** | Примеры кода для тестирования | Тестирование функций |
| **SETUP_GUIDE.md** | Подробная инструкция | Детальная настройка |
| **CHECKLIST.md** | Чек-лист проверки | Проверка перед сдачей |
| **README.md** | Полная документация | Изучение проекта |

---

## 🎬 Демо-сценарии

### 🟢 Сценарий 1: Гость → Пользователь (3 мин)

**Шаг 1: Регистрация**
```javascript
// Или через интерфейс: Регистрация → заполнить форму
// Логин: demouser
// Email: demo@example.com
// Пароль: demo123
```

**Шаг 2: Бронирование**
1. Каталог → выбрать ресторан
2. "Забронировать"
3. Дата: завтра
4. Время: 19:00
5. Гости: 4
6. "Подтвердить"

**Шаг 3: Проверка**
1. Профиль → "Мои бронирования"
2. Видите созданное бронирование

### 🔴 Сценарий 2: Работа администратора (2 мин)

**Быстрый вход через консоль:**
```javascript
localStorage.setItem('tablereserve_current_user', JSON.stringify({
  id: '1',
  login: 'admin',
  email: 'admin@tablereserve.ru',
  isAdmin: true
}));
location.reload();
```

**Модерация:**
1. Щит 🛡️ → Админ-панель
2. "Бронирования"
3. Найти "Ожидает" → нажать ✓
4. Статус → "Подтверждено"
5. "Отзывы" → удалить любой

---

## 🛠️ Полезные команды

### Войти быстро (консоль)

**Как админ:**
```javascript
localStorage.setItem('tablereserve_current_user', JSON.stringify({
  id: '1', login: 'admin', email: 'admin@tablereserve.ru', isAdmin: true
}));
location.reload();
```

**Как пользователь:**
```javascript
localStorage.setItem('tablereserve_current_user', JSON.stringify({
  id: '2', login: 'user', email: 'user@example.com', isAdmin: false
}));
location.reload();
```

**Выйти:**
```javascript
localStorage.removeItem('tablereserve_current_user');
location.reload();
```

### Создать тестовое бронирование
```javascript
const bookings = JSON.parse(localStorage.getItem('tablereserve_bookings'));
const restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants'));
const tomorrow = new Date();
tomorrow.setDate(tomorrow.getDate() + 1);
tomorrow.setHours(19, 0, 0, 0);

bookings.push({
  id: Date.now().toString(),
  userId: '2',
  restaurantId: restaurants[0].id,
  guests: 4,
  bookingDate: tomorrow.toISOString(),
  status: 'created',
  createdAt: new Date().toISOString()
});

localStorage.setItem('tablereserve_bookings', JSON.stringify(bookings));
console.log('✅ Тестовое бронирование создано');
location.reload();
```

### Посмотреть всю статистику
```javascript
const data = {
  users: JSON.parse(localStorage.getItem('tablereserve_users')),
  restaurants: JSON.parse(localStorage.getItem('tablereserve_restaurants')),
  bookings: JSON.parse(localStorage.getItem('tablereserve_bookings')),
  feedbacks: JSON.parse(localStorage.getItem('tablereserve_feedbacks'))
};

console.log('👥 Пользователи:', data.users.length);
console.table(data.users.map(u => ({
  Login: u.login,
  Email: u.email,
  Admin: u.isAdmin ? 'Да' : 'Нет'
})));

console.log('\n🍽️ Рестораны:', data.restaurants.length);
console.table(data.restaurants.map(r => ({
  Название: r.name,
  Кухня: r.cuisine,
  Рейтинг: r.rating
})));

console.log('\n📅 Бронирования:', data.bookings.length);
console.table(data.bookings);

console.log('\n💬 Отзывы:', data.feedbacks.length);
console.table(data.feedbacks);
```

### Сбросить всё
```javascript
if (confirm('Удалить ВСЕ данные и начать заново?')) {
  localStorage.clear();
  location.reload();
}
```

---

## 🚨 Решение проблем

### Проблема: Пустая база данных
**Решение:**
```javascript
localStorage.clear();
location.reload();
```

### Проблема: Не могу войти
**Решение:**
```javascript
// Проверить пароли
const users = JSON.parse(localStorage.getItem('tablereserve_users'));
console.table(users.map(u => ({ Email: u.email, Password: u.password })));
```

### Проблема: Админ-панель не открывается
**Решение:**
```javascript
// Проверить текущего пользователя
const current = JSON.parse(localStorage.getItem('tablereserve_current_user'));
console.log('Пользователь:', current);
console.log('Админ?', current?.isAdmin);

// Если нет - войти заново
```

---

## ✅ Минимальная проверка перед сдачей

Выполните в консоли:
```javascript
const checks = {
  'БД инициализирована': localStorage.getItem('tablereserve_initialized') === 'true',
  'Есть пользователи': JSON.parse(localStorage.getItem('tablereserve_users')).length >= 2,
  'Есть рестораны': JSON.parse(localStorage.getItem('tablereserve_restaurants')).length >= 6,
  'Есть админ': JSON.parse(localStorage.getItem('tablereserve_users')).some(u => u.isAdmin),
  'Регистрация работает': true, // проверить вручную
  'Бронирование работает': true, // проверить вручную
  'Админ-панель работает': true  // проверить вручную
};

console.table(checks);
console.log('Всё готово?', Object.values(checks).every(v => v === true) ? '✅ ДА' : '❌ НЕТ');
```

---

## 🎉 Готово!

Если все проверки пройдены:
1. ✅ База данных работает
2. ✅ Регистрация/Вход работает
3. ✅ Бронирование работает
4. ✅ Админ-панель работает

**Проект готов к сдаче! 🚀**

---

## 📞 Поддержка

Если возникли вопросы:
1. Проверьте **LAUNCH_INSTRUCTIONS.md**
2. Проверьте **QUICK_START_CODE.md**
3. Проверьте **README.md**
4. Откройте консоль и проверьте ошибки

---

**Дата создания:** 17 декабря 2025  
**Версия:** 1.0.0  
**Статус:** ✅ Готов к использованию
