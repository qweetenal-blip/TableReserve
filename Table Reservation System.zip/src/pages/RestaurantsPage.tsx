import React, { useState, useEffect } from 'react';
import { Search, Filter } from '../components/Icons';
import { RestaurantCard } from '../components/RestaurantCard';
import { restaurantService } from '../services/restaurantService';
import type { Restaurant } from '../App';

type RestaurantsPageProps = {
  navigateTo: (page: string, restaurantId?: string) => void;
};

export function RestaurantsPage({ navigateTo }: RestaurantsPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCuisine, setSelectedCuisine] = useState('Все');
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);

  // Загружаем рестораны при монтировании компонента
  useEffect(() => {
    const allRestaurants = restaurantService.getAll();
    setRestaurants(allRestaurants);
  }, []);

  const cuisines = ['Все', ...restaurantService.getCuisines()];

  const filteredRestaurants = restaurants.filter(restaurant => {
    const matchesSearch = restaurant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         restaurant.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCuisine = selectedCuisine === 'Все' || restaurant.cuisine === selectedCuisine;
    return matchesSearch && matchesCuisine;
  });

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Заголовок */}
      <div className="mb-8">
        <h1 className="text-gray-900 mb-4">Рестораны</h1>
        <p className="text-gray-600">
          Выберите идеальное место для вашего визита из {restaurants.length} заведений
        </p>
      </div>

      {/* Фильтры и поиск */}
      <div className="bg-white p-6 rounded-xl shadow-md mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Поиск */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Поиск по названию или описанию..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
            />
          </div>

          {/* Фильтр по кухне */}
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <select
              value={selectedCuisine}
              onChange={(e) => setSelectedCuisine(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 appearance-none bg-white"
            >
              {cuisines.map(cuisine => (
                <option key={cuisine} value={cuisine}>
                  {cuisine === 'Все' ? 'Все кухни' : cuisine}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Результаты */}
      <div className="mb-6">
        <p className="text-gray-600">
          Найдено заведений: <span className="font-semibold">{filteredRestaurants.length}</span>
        </p>
      </div>

      {/* Список ресторанов */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredRestaurants.map((restaurant) => (
          <RestaurantCard
            key={restaurant.id}
            restaurant={restaurant}
            onViewDetails={() => navigateTo('restaurant-detail', restaurant.id)}
            onBook={() => navigateTo('booking', restaurant.id)}
          />
        ))}
      </div>

      {/* Пустое состояние */}
      {filteredRestaurants.length === 0 && (
        <div className="text-center py-16">
          <p className="text-gray-600 mb-4">
            Не найдено ресторанов по вашему запросу
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCuisine('Все');
            }}
            className="text-orange-500 hover:text-orange-600"
          >
            Сбросить фильтры
          </button>
        </div>
      )}
    </div>
  );
}