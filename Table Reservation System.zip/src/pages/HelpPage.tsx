import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, MessageCircle } from '../components/Icons';

export function HelpPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Имитация отправки формы
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({ name: '', email: '', subject: '', message: '' });
    }, 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        {/* Заголовок */}
        <div className="text-center mb-12">
          <h1 className="text-gray-900 mb-4">Контакты и поддержка</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Есть вопросы или предложения? Мы всегда рады помочь. Свяжитесь с нами любым удобным способом.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Форма обратной связи */}
          <div className="bg-white rounded-xl shadow-lg p-8">
            <div className="flex items-center gap-3 mb-6">
              <MessageCircle className="w-6 h-6 text-orange-500" />
              <h2 className="text-gray-900">Форма обратной связи</h2>
            </div>

            {submitted ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Send className="w-8 h-8 text-green-500" />
                </div>
                <h3 className="text-gray-900 mb-2">Сообщение отправлено!</h3>
                <p className="text-gray-600">
                  Мы получили ваше сообщение и свяжемся с вами в ближайшее время.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-gray-700 mb-2">
                    Ваше имя *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    placeholder="Введите ваше имя"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-gray-700 mb-2">
                    Email *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    placeholder="your@email.com"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-gray-700 mb-2">
                    Тема обращения *
                  </label>
                  <select
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    <option value="">Выберите тему</option>
                    <option value="booking">Вопрос о бронировании</option>
                    <option value="restaurant">Информация о ресторане</option>
                    <option value="feedback">Отзыв или жалоба</option>
                    <option value="technical">Техническая проблема</option>
                    <option value="other">Другое</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-700 mb-2">
                    Сообщение *
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={5}
                    placeholder="Опишите ваш вопрос или проблему..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-orange-500 text-white py-3 rounded-lg hover:bg-orange-600 transition-colors flex items-center justify-center gap-2"
                >
                  <Send className="w-5 h-5" />
                  Отправить сообщение
                </button>
              </form>
            )}
          </div>

          {/* Контактная информация */}
          <div className="space-y-6">
            {/* Основные контакты */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h2 className="text-gray-900 mb-6">Контактная информация</h2>
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-orange-500" />
                  </div>
                  <div>
                    <h4 className="text-gray-900 mb-1">Телефон</h4>
                    <p className="text-gray-600">+7 (800) 123-45-67</p>
                    <p className="text-sm text-gray-500">Ежедневно с 9:00 до 22:00</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-orange-500" />
                  </div>
                  <div>
                    <h4 className="text-gray-900 mb-1">Email</h4>
                    <p className="text-gray-600">info@tablereserve.ru</p>
                    <p className="text-gray-600">support@tablereserve.ru</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-orange-500" />
                  </div>
                  <div>
                    <h4 className="text-gray-900 mb-1">Адрес офиса</h4>
                    <p className="text-gray-600">Москва, ул. Примерная, 1</p>
                    <p className="text-sm text-gray-500">Офис 301, 3 этаж</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Часто задаваемые вопросы */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h2 className="text-gray-900 mb-6">Часто задаваемые вопросы</h2>
              <div className="space-y-4">
                <div>
                  <h4 className="text-gray-900 mb-2">Как забронировать стол?</h4>
                  <p className="text-sm text-gray-600">
                    Выберите ресторан, укажите дату, время и количество гостей, затем подтвердите бронирование.
                  </p>
                </div>

                <div>
                  <h4 className="text-gray-900 mb-2">Можно ли отменить бронирование?</h4>
                  <p className="text-sm text-gray-600">
                    Да, вы можете отменить бронирование в личном кабинете не позднее чем за 2 часа до времени визита.
                  </p>
                </div>

                <div>
                  <h4 className="text-gray-900 mb-2">Нужна ли регистрация?</h4>
                  <p className="text-sm text-gray-600">
                    Регистрация необходима для создания бронирований и доступа к личному кабинету.
                  </p>
                </div>

                <div>
                  <h4 className="text-gray-900 mb-2">Как оставить отзыв?</h4>
                  <p className="text-sm text-gray-600">
                    После посещения ресторана вы можете оставить отзыв на странице заведения или в личном кабинете.
                  </p>
                </div>
              </div>
            </div>

            {/* Онлайн чат */}
            <div className="bg-gradient-to-r from-orange-500 to-red-500 rounded-xl shadow-lg p-8 text-white">
              <h3 className="text-white mb-4">Нужна помощь прямо сейчас?</h3>
              <p className="mb-6 text-orange-50">
                Наша служба поддержки готова ответить на ваши вопросы в онлайн-чате.
              </p>
              <button className="bg-white text-orange-500 px-6 py-3 rounded-lg hover:bg-gray-100 transition-colors flex items-center gap-2">
                <MessageCircle className="w-5 h-5" />
                Начать чат
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}