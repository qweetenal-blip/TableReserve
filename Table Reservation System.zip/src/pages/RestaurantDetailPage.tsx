import React, { useState, useEffect } from 'react';
import { MapPin, Users, Star, Clock, Phone, Mail, ArrowLeft } from '../components/Icons';
import { restaurantService } from '../services/restaurantService';
import { feedbackService } from '../services/feedbackService';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import type { Restaurant, Feedback } from '../App';

type RestaurantDetailPageProps = {
  restaurantId: string;
  navigateTo: (page: string, restaurantId?: string) => void;
};

export function RestaurantDetailPage({ restaurantId, navigateTo }: RestaurantDetailPageProps) {
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [restaurantFeedbacks, setRestaurantFeedbacks] = useState<Feedback[]>([]);

  useEffect(() => {
    const restaurantData = restaurantService.getById(restaurantId);
    setRestaurant(restaurantData);

    if (restaurantData) {
      const feedbacks = feedbackService.getByRestaurantId(restaurantId);
      setRestaurantFeedbacks(feedbacks);
    }
  }, [restaurantId]);

  if (!restaurant) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <p className="text-gray-600 mb-4">Ресторан не найден</p>
        <button
          onClick={() => navigateTo('restaurants')}
          className="text-orange-500 hover:text-orange-600"
        >
          Вернуться к списку
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Кнопка назад */}
      <div className="container mx-auto px-4 py-4">
        <button
          onClick={() => navigateTo('restaurants')}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5" />
          Назад к ресторанам
        </button>
      </div>

      {/* Изображение заведения */}
      <div className="relative h-96 overflow-hidden">
        <ImageWithFallback 
          src={restaurant.image}
          alt={restaurant.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
        <div className="absolute bottom-8 left-0 right-0 container mx-auto px-4">
          <div className="flex items-end justify-between">
            <div className="text-white">
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-white">{restaurant.name}</h1>
                <span className="bg-white text-orange-500 px-3 py-1 rounded-full text-sm">
                  {restaurant.cuisine}
                </span>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1">
                  <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  <span>{restaurant.rating}</span>
                </div>
                <div className="flex items-center gap-1">
                  <MapPin className="w-5 h-5" />
                  <span>{restaurant.location}</span>
                </div>
              </div>
            </div>
            <button
              onClick={() => navigateTo('booking', restaurant.id)}
              className="bg-orange-500 text-white px-8 py-3 rounded-lg hover:bg-orange-600 transition-colors"
            >
              Забронировать стол
            </button>
          </div>
        </div>
      </div>

      {/* Основной контент */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Левая колонка - основная информация */}
          <div className="lg:col-span-2 space-y-8">
            {/* Описание */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-gray-900 mb-4">О ресторане</h2>
              <p className="text-gray-600">
                {restaurant.description}
              </p>
            </div>

            {/* Меню */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-gray-900 mb-4">Меню</h2>
              <div className="space-y-2">
                {restaurant.menu.split(',').map((item, index) => (
                  <div key={index} className="flex items-center gap-2 text-gray-700">
                    <span className="w-2 h-2 bg-orange-500 rounded-full"></span>
                    <span>{item.trim()}</span>
                  </div>
                ))}
              </div>
              <p className="text-sm text-gray-500 mt-4">
                * Полное меню доступно в заведении
              </p>
            </div>

            {/* Отзывы */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-gray-900 mb-4">Отзывы</h2>
              {restaurantFeedbacks.length > 0 ? (
                <div className="space-y-4">
                  {restaurantFeedbacks.map((feedback) => (
                    <div key={feedback.id} className="border-b border-gray-200 last:border-0 pb-4 last:pb-0">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-gray-900">{feedback.name}</h4>
                        <div className="flex items-center gap-1">
                          {[...Array(feedback.rating || 0)].map((_, i) => (
                            <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          ))}
                        </div>
                      </div>
                      <p className="text-gray-600 text-sm">{feedback.message}</p>
                      <p className="text-xs text-gray-400 mt-2">
                        {new Date(feedback.createdAt).toLocaleDateString('ru-RU')}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500">Пока нет отзывов. Будьте первым!</p>
              )}
            </div>
          </div>

          {/* Правая колонка - информация */}
          <div className="space-y-6">
            {/* Контактная информация */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h3 className="mb-4">Контакты</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-gray-600">
                  <Phone className="w-5 h-5 text-orange-500" />
                  <span>+7 (800) 123-45-67</span>
                </div>
                <div className="flex items-center gap-3 text-gray-600">
                  <Mail className="w-5 h-5 text-orange-500" />
                  <span>info@restaurant.ru</span>
                </div>
                <div className="flex items-center gap-3 text-gray-600">
                  <MapPin className="w-5 h-5 text-orange-500" />
                  <span>{restaurant.location}</span>
                </div>
              </div>
            </div>

            {/* Информация о заведении */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h3 className="mb-4">Информация</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Вместимость:</span>
                  <div className="flex items-center gap-1">
                    <Users className="w-4 h-4 text-orange-500" />
                    <span>{restaurant.capacity} мест</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Рейтинг:</span>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span>{restaurant.rating} / 5</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Режим работы:</span>
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4 text-orange-500" />
                    <span>10:00 - 23:00</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Кнопка бронирования */}
            <button
              onClick={() => navigateTo('booking', restaurant.id)}
              className="w-full bg-orange-500 text-white px-6 py-3 rounded-lg hover:bg-orange-600 transition-colors"
            >
              Забронировать стол
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}