import React, { useState } from 'react';
import { LogIn, Mail, Lock } from '../components/Icons';
import { authService } from '../services/authService';
import type { User } from '../App';

type LoginPageProps = {
  onLogin: (user: User) => void;
  navigateTo: (page: string) => void;
};

export function LoginPage({ onLogin, navigateTo }: LoginPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Используем новый authService
    const result = authService.login({ email, password });
    
    if (result.success && result.user) {
      onLogin(result.user);
    } else {
      setError(result.error || 'Неверный email или пароль');
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center py-12 px-4">
      <div className="max-w-md w-full">
        {/* Карточка входа */}
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          {/* Заголовок */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <LogIn className="w-8 h-8 text-orange-500" />
            </div>
            <h1 className="text-gray-900 mb-2">Вход в систему</h1>
            <p className="text-gray-600">
              Войдите в свой аккаунт TableReserve
            </p>
          </div>

          {/* Демо аккаунты */}
          <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm text-blue-800 mb-2">Демо аккаунты для входа:</p>
            <div className="text-xs text-blue-700 space-y-1">
              <p>👤 <strong>Пользователь:</strong> user@example.com</p>
              <p>🛡️ <strong>Администратор:</strong> admin@tablereserve.ru</p>
              <p className="text-blue-600 mt-2"><strong>Пароль для обоих:</strong> admin123 / user123</p>
            </div>
          </div>

          {/* Форма */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
                {error}
              </div>
            )}

            <div>
              <label className="block text-gray-700 mb-2">
                Email
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="your@email.com"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-gray-700 mb-2">
                Пароль
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center">
                <input type="checkbox" className="mr-2" />
                <span className="text-sm text-gray-600">Запомнить меня</span>
              </label>
              <button type="button" className="text-sm text-orange-500 hover:text-orange-600">
                Забыли пароль?
              </button>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-orange-500 text-white py-3 rounded-lg hover:bg-orange-600 transition-colors flex items-center justify-center gap-2 disabled:bg-gray-400"
            >
              <LogIn className="w-5 h-5" />
              {isLoading ? 'Вход...' : 'Войти'}
            </button>
          </form>

          {/* Регистрация */}
          <div className="mt-6 text-center">
            <p className="text-gray-600">
              Нет аккаунта?{' '}
              <button
                onClick={() => navigateTo('register')}
                className="text-orange-500 hover:text-orange-600"
              >
                Зарегистрироваться
              </button>
            </p>
          </div>

          {/* Назад */}
          <div className="mt-4 text-center">
            <button
              onClick={() => navigateTo('main')}
              className="text-sm text-gray-500 hover:text-gray-700"
            >
              ← Вернуться на главную
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}