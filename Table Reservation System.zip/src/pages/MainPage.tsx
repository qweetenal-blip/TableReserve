import React, { useState, useEffect } from 'react';
import { Calendar, Search, CheckCircle, Sparkles } from '../components/Icons';
import { RestaurantCard } from '../components/RestaurantCard';
import { restaurantService } from '../services/restaurantService';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import type { Restaurant } from '../App';

type MainPageProps = {
  navigateTo: (page: string, restaurantId?: string) => void;
};

export function MainPage({ navigateTo }: MainPageProps) {
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);

  useEffect(() => {
    const allRestaurants = restaurantService.getAll();
    setRestaurants(allRestaurants);
  }, []);

  const featuredRestaurants = restaurants.slice(0, 3);

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-orange-500 to-red-500 text-white">
        <div className="container mx-auto px-4 py-20">
          <div className="max-w-3xl">
            <h1 className="text-white mb-6">
              Забронируйте стол в лучшем ресторане города!
            </h1>
            <p className="text-xl mb-8 text-orange-50">
              Откройте для себя изысканные рестораны, уютные кафе и стильные бары. 
              Бронируйте столы онлайн за считанные секунды.
            </p>
            <div className="flex gap-4">
              <button
                onClick={() => navigateTo('restaurants')}
                className="bg-white text-orange-500 px-8 py-3 rounded-lg hover:bg-gray-100 transition-colors"
              >
                Выбрать ресторан
              </button>
              <button
                onClick={() => navigateTo('help')}
                className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-lg hover:bg-white hover:text-orange-500 transition-colors"
              >
                Узнать больше
              </button>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-gray-50 to-transparent"></div>
      </section>

      {/* Информационный блок */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Sparkles className="w-6 h-6 text-orange-500" />
            <h2 className="text-gray-900">Откройте для себя лучшие рестораны</h2>
          </div>
          <p className="text-gray-600">
            TableReserve предлагает широкий выбор заведений общественного питания с разнообразным меню, 
            от традиционной кухни до авторских блюд от шеф-поваров. Наслаждайтесь незабываемыми 
            гастрономическими впечатлениями и идеальным сервисом.
          </p>
        </div>

        {/* Преимущества */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="text-center p-6 bg-white rounded-xl shadow-md">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-orange-500" />
            </div>
            <h3 className="mb-2">Удобный поиск</h3>
            <p className="text-gray-600 text-sm">
              Найдите идеальный ресторан по кухне, местоположению и рейтингу
            </p>
          </div>

          <div className="text-center p-6 bg-white rounded-xl shadow-md">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Calendar className="w-8 h-8 text-orange-500" />
            </div>
            <h3 className="mb-2">Онлайн бронирование</h3>
            <p className="text-gray-600 text-sm">
              Забронируйте стол в несколько кликов на удобное время
            </p>
          </div>

          <div className="text-center p-6 bg-white rounded-xl shadow-md">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-orange-500" />
            </div>
            <h3 className="mb-2">Гарантия места</h3>
            <p className="text-gray-600 text-sm">
              Ваше бронирование подтверждается мгновенно
            </p>
          </div>
        </div>
      </section>

      {/* Популярные рестораны */}
      <section className="bg-white py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-gray-900 mb-4">Популярные рестораны</h2>
            <p className="text-gray-600">
              Откройте для себя самые востребованные заведения
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-8">
            {featuredRestaurants.map((restaurant) => (
              <RestaurantCard
                key={restaurant.id}
                restaurant={restaurant}
                onViewDetails={() => navigateTo('restaurant-detail', restaurant.id)}
                onBook={() => navigateTo('booking', restaurant.id)}
              />
            ))}
          </div>

          <div className="text-center">
            <button
              onClick={() => navigateTo('restaurants')}
              className="bg-orange-500 text-white px-8 py-3 rounded-lg hover:bg-orange-600 transition-colors"
            >
              Посмотреть все рестораны
            </button>
          </div>
        </div>
      </section>

      {/* Как забронировать стол */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-gray-900 mb-4">Как забронировать стол</h2>
          <p className="text-gray-600">
            Простой процесс бронирования за 4 шага
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="w-12 h-12 bg-orange-500 text-white rounded-full flex items-center justify-center mx-auto mb-4">
              1
            </div>
            <h4 className="mb-2">Выберите ресторан</h4>
            <p className="text-gray-600 text-sm">
              Найдите заведение по вашему вкусу
            </p>
          </div>

          <div className="text-center">
            <div className="w-12 h-12 bg-orange-500 text-white rounded-full flex items-center justify-center mx-auto mb-4">
              2
            </div>
            <h4 className="mb-2">Укажите дату и время</h4>
            <p className="text-gray-600 text-sm">
              Выберите удобное время визита
            </p>
          </div>

          <div className="text-center">
            <div className="w-12 h-12 bg-orange-500 text-white rounded-full flex items-center justify-center mx-auto mb-4">
              3
            </div>
            <h4 className="mb-2">Количество гостей</h4>
            <p className="text-gray-600 text-sm">
              Укажите число персон
            </p>
          </div>

          <div className="text-center">
            <div className="w-12 h-12 bg-orange-500 text-white rounded-full flex items-center justify-center mx-auto mb-4">
              4
            </div>
            <h4 className="mb-2">Подтвердите</h4>
            <p className="text-gray-600 text-sm">
              Получите подтверждение бронирования
            </p>
          </div>
        </div>

        <div className="text-center mt-12">
          <button
            onClick={() => navigateTo('restaurants')}
            className="bg-orange-500 text-white px-8 py-3 rounded-lg hover:bg-orange-600 transition-colors"
          >
            Начать бронирование
          </button>
        </div>
      </section>
    </div>
  );
}