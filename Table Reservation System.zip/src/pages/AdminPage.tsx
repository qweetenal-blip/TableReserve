import React, { useState, useEffect } from 'react';
import { Users, Calendar, MessageSquare, UtensilsCrossed, Plus, Edit, Trash2, Check, X, TrendingUp, Activity } from '../components/Icons';
import { adminService } from '../services/adminService';
import { restaurantService } from '../services/restaurantService';
import { bookingService } from '../services/bookingService';
import { feedbackService } from '../services/feedbackService';
import type { User, Restaurant, Booking, Feedback } from '../App';

type AdminPageProps = {
  currentUser: User | null;
  navigateTo: (page: string) => void;
};

export function AdminPage({ currentUser, navigateTo }: AdminPageProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'restaurants' | 'bookings' | 'feedback' | 'users'>('overview');
  const [stats, setStats] = useState<any>(null);
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    if (currentUser?.isAdmin) {
      loadData();
    }
  }, [currentUser]);

  const loadData = () => {
    try {
      // Загружаем статистику
      const statsData = adminService.getStats(currentUser);
      setStats(statsData);

      // Загружаем данные
      setRestaurants(restaurantService.getAll());
      setBookings(bookingService.getAll(currentUser));
      setFeedbacks(feedbackService.getAll());
      setUsers(adminService.getAllUsers(currentUser));
    } catch (error) {
      console.error('Ошибка загрузки данных:', error);
    }
  };

  if (!currentUser || !currentUser.isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <X className="w-10 h-10 text-red-500" />
          </div>
          <h2 className="text-gray-900 mb-2">Доступ запрещен</h2>
          <p className="text-gray-600 mb-6">У вас нет прав для доступа к админ-панели</p>
          <button
            onClick={() => navigateTo('main')}
            className="bg-orange-500 text-white px-6 py-3 rounded-lg hover:bg-orange-600 transition-colors"
          >
            На главную
          </button>
        </div>
      </div>
    );
  }

  const handleDeleteRestaurant = (id: string) => {
    if (confirm('Вы уверены, что хотите удалить этот ресторан?')) {
      try {
        restaurantService.delete(currentUser, id);
        loadData();
      } catch (error: any) {
        alert(error.message);
      }
    }
  };

  const handleDeleteBooking = (id: string) => {
    if (confirm('Вы уверены, что хотите удалить это бронирование?')) {
      try {
        bookingService.delete(currentUser, id);
        loadData();
      } catch (error: any) {
        alert(error.message);
      }
    }
  };

  const handleUpdateBookingStatus = (id: string, status: Booking['status']) => {
    try {
      bookingService.updateStatus(currentUser, id, status);
      loadData();
    } catch (error: any) {
      alert(error.message);
    }
  };

  const handleDeleteFeedback = (id: string) => {
    if (confirm('Вы уверены, что хотите удалить этот отзыв?')) {
      try {
        feedbackService.delete(currentUser, id);
        loadData();
      } catch (error: any) {
        alert(error.message);
      }
    }
  };

  const handleDeleteUser = (id: string) => {
    if (confirm('Вы уверены, что хотите удалить этого пользователя?')) {
      try {
        adminService.deleteUser(currentUser, id);
        loadData();
      } catch (error: any) {
        alert(error.message);
      }
    }
  };

  const handleToggleAdminRole = (id: string, isAdmin: boolean) => {
    try {
      adminService.changeUserRole(currentUser, id, !isAdmin);
      loadData();
    } catch (error: any) {
      alert(error.message);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-green-100 text-green-700';
      case 'created': return 'bg-yellow-100 text-yellow-700';
      case 'cancelled': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'confirmed': return 'Подтверждено';
      case 'created': return 'Ожидает';
      case 'cancelled': return 'Отменено';
      default: return status;
    }
  };

  const getRestaurantName = (restaurantId: string) => {
    const restaurant = restaurants.find(r => r.id === restaurantId);
    return restaurant?.name || 'Не найден';
  };

  const getUserEmail = (userId: string) => {
    const user = users.find(u => u.id === userId);
    return user?.email || 'Не найден';
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Заголовок */}
        <div className="mb-8">
          <h1 className="text-gray-900 mb-2">Панель администратора</h1>
          <p className="text-gray-600">Управление системой TableReserve</p>
        </div>

        {/* Вкладки */}
        <div className="bg-white rounded-xl shadow-md mb-8 overflow-hidden">
          <div className="flex border-b overflow-x-auto">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-6 py-4 whitespace-nowrap transition-colors ${
                activeTab === 'overview' ? 'bg-purple-500 text-white' : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              Обзор
            </button>
            <button
              onClick={() => setActiveTab('restaurants')}
              className={`px-6 py-4 whitespace-nowrap transition-colors ${
                activeTab === 'restaurants' ? 'bg-purple-500 text-white' : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              Рестораны ({restaurants.length})
            </button>
            <button
              onClick={() => setActiveTab('bookings')}
              className={`px-6 py-4 whitespace-nowrap transition-colors ${
                activeTab === 'bookings' ? 'bg-purple-500 text-white' : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              Бронирования ({bookings.length})
            </button>
            <button
              onClick={() => setActiveTab('feedback')}
              className={`px-6 py-4 whitespace-nowrap transition-colors ${
                activeTab === 'feedback' ? 'bg-purple-500 text-white' : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              Отзывы ({feedbacks.length})
            </button>
            <button
              onClick={() => setActiveTab('users')}
              className={`px-6 py-4 whitespace-nowrap transition-colors ${
                activeTab === 'users' ? 'bg-purple-500 text-white' : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              Пользователи ({users.length})
            </button>
          </div>

          <div className="p-6">
            {/* Обзор */}
            {activeTab === 'overview' && stats && (
              <div>
                <h2 className="text-gray-900 mb-6">Общая статистика</h2>
                
                {/* Статистические карточки */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                  <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white">
                    <div className="flex items-center justify-between mb-4">
                      <Users className="w-8 h-8 opacity-80" />
                      <span className="text-3xl">{stats.totalUsers}</span>
                    </div>
                    <p className="text-blue-100">Всего пользователей</p>
                  </div>

                  <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl p-6 text-white">
                    <div className="flex items-center justify-between mb-4">
                      <UtensilsCrossed className="w-8 h-8 opacity-80" />
                      <span className="text-3xl">{stats.totalRestaurants}</span>
                    </div>
                    <p className="text-orange-100">Всего ресторанов</p>
                  </div>

                  <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white">
                    <div className="flex items-center justify-between mb-4">
                      <Calendar className="w-8 h-8 opacity-80" />
                      <span className="text-3xl">{stats.totalBookings}</span>
                    </div>
                    <p className="text-green-100">Всего бронирований</p>
                  </div>

                  <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-6 text-white">
                    <div className="flex items-center justify-between mb-4">
                      <MessageSquare className="w-8 h-8 opacity-80" />
                      <span className="text-3xl">{stats.totalFeedbacks}</span>
                    </div>
                    <p className="text-purple-100">Всего отзывов</p>
                  </div>
                </div>

                {/* Детальная статистика */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white border border-gray-200 rounded-xl p-6">
                    <h3 className="text-gray-900 mb-4">Статистика бронирований</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Активные:</span>
                        <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full">
                          {stats.activeBookings}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Ожидающие:</span>
                        <span className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full">
                          {stats.pendingBookings}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Отмененные:</span>
                        <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full">
                          {stats.cancelledBookings}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white border border-gray-200 rounded-xl p-6">
                    <h3 className="text-gray-900 mb-4">Средний рейтинг</h3>
                    <div className="flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-5xl text-orange-500 mb-2">
                          {stats.averageRating.toFixed(1)}
                        </div>
                        <div className="text-gray-600">из 5.0</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Рестораны */}
            {activeTab === 'restaurants' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-gray-900">Управление ресторанами</h2>
                  <button className="bg-purple-500 text-white px-4 py-2 rounded-lg hover:bg-purple-600 transition-colors flex items-center gap-2">
                    <Plus className="w-5 h-5" />
                    Добавить ресторан
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">Название</th>
                        <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">Кухня</th>
                        <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">Вместимость</th>
                        <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">Рейтинг</th>
                        <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">Действия</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {restaurants.map(restaurant => (
                        <tr key={restaurant.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-gray-900">{restaurant.name}</div>
                            <div className="text-sm text-gray-500">{restaurant.location}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                            {restaurant.cuisine}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                            {restaurant.capacity} мест
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="text-orange-500">★ {restaurant.rating}</span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex gap-2">
                              <button className="text-blue-500 hover:text-blue-600">
                                <Edit className="w-5 h-5" />
                              </button>
                              <button
                                onClick={() => handleDeleteRestaurant(restaurant.id)}
                                className="text-red-500 hover:text-red-600"
                              >
                                <Trash2 className="w-5 h-5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Бронирования */}
            {activeTab === 'bookings' && (
              <div>
                <h2 className="text-gray-900 mb-6">Управление бронированиями</h2>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">Пользователь</th>
                        <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">Ресторан</th>
                        <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">Дата</th>
                        <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">Гости</th>
                        <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">Статус</th>
                        <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">Действия</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {bookings.map(booking => (
                        <tr key={booking.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            {getUserEmail(booking.userId)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                            {getRestaurantName(booking.restaurantId)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            {new Date(booking.bookingDate).toLocaleString('ru-RU')}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            {booking.guests}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(booking.status)}`}>
                              {getStatusText(booking.status)}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex gap-2">
                              {booking.status === 'created' && (
                                <button
                                  onClick={() => handleUpdateBookingStatus(booking.id, 'confirmed')}
                                  className="text-green-500 hover:text-green-600"
                                  title="Подтвердить"
                                >
                                  <Check className="w-5 h-5" />
                                </button>
                              )}
                              {booking.status !== 'cancelled' && (
                                <button
                                  onClick={() => handleUpdateBookingStatus(booking.id, 'cancelled')}
                                  className="text-orange-500 hover:text-orange-600"
                                  title="Отменить"
                                >
                                  <X className="w-5 h-5" />
                                </button>
                              )}
                              <button
                                onClick={() => handleDeleteBooking(booking.id)}
                                className="text-red-500 hover:text-red-600"
                                title="Удалить"
                              >
                                <Trash2 className="w-5 h-5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Отзывы */}
            {activeTab === 'feedback' && (
              <div>
                <h2 className="text-gray-900 mb-6">Управление отзывами</h2>

                <div className="space-y-4">
                  {feedbacks.map(feedback => (
                    <div key={feedback.id} className="bg-white border border-gray-200 rounded-lg p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-gray-900 mb-1">{feedback.name}</h3>
                          <p className="text-sm text-gray-500">{feedback.email}</p>
                          {feedback.restaurantId && (
                            <p className="text-sm text-gray-500 mt-1">
                              Ресторан: {getRestaurantName(feedback.restaurantId)}
                            </p>
                          )}
                        </div>
                        <div className="flex items-center gap-4">
                          {feedback.rating && (
                            <span className="text-orange-500">★ {feedback.rating}</span>
                          )}
                          <button
                            onClick={() => handleDeleteFeedback(feedback.id)}
                            className="text-red-500 hover:text-red-600"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                      <p className="text-gray-600">{feedback.message}</p>
                      <p className="text-xs text-gray-400 mt-3">
                        {new Date(feedback.createdAt).toLocaleString('ru-RU')}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Пользователи */}
            {activeTab === 'users' && (
              <div>
                <h2 className="text-gray-900 mb-6">Управление пользователями</h2>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">Логин</th>
                        <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">Email</th>
                        <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">Роль</th>
                        <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase tracking-wider">Действия</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {users.map(user => (
                        <tr key={user.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap text-gray-900">
                            {user.login}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                            {user.email}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 rounded-full text-xs ${
                              user.isAdmin ? 'bg-purple-100 text-purple-700' : 'bg-gray-100 text-gray-700'
                            }`}>
                              {user.isAdmin ? 'Администратор' : 'Пользователь'}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex gap-2">
                              <button
                                onClick={() => handleToggleAdminRole(user.id, user.isAdmin || false)}
                                className="text-blue-500 hover:text-blue-600 text-sm"
                              >
                                {user.isAdmin ? 'Снять права' : 'Сделать админом'}
                              </button>
                              {user.id !== currentUser.id && (
                                <button
                                  onClick={() => handleDeleteUser(user.id)}
                                  className="text-red-500 hover:text-red-600"
                                >
                                  <Trash2 className="w-5 h-5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
