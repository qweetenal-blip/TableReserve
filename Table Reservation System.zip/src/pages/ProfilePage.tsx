import React, { useState, useEffect } from 'react';
import { Calendar, Star, Clock, MapPin, Mail, Edit2, X, Check, LogOut } from '../components/Icons';
import { bookingService } from '../services/bookingService';
import { feedbackService } from '../services/feedbackService';
import { restaurantService } from '../services/restaurantService';
import type { User, Booking, Feedback } from '../App';

type ProfilePageProps = {
  currentUser: User | null;
  navigateTo: (page: string, restaurantId?: string) => void;
  onLogout: () => void;
};

export function ProfilePage({ currentUser, navigateTo, onLogout }: ProfilePageProps) {
  const [activeTab, setActiveTab] = useState<'bookings' | 'favorites' | 'reviews'>('bookings');
  const [userBookings, setUserBookings] = useState<Booking[]>([]);
  const [userReviews, setUserReviews] = useState<Feedback[]>([]);

  useEffect(() => {
    if (currentUser) {
      loadUserData();
    }
  }, [currentUser]);

  const loadUserData = () => {
    if (!currentUser) return;

    try {
      const bookings = bookingService.getUserBookings(currentUser);
      setUserBookings(bookings);

      const allFeedbacks = feedbackService.getAll();
      const reviews = allFeedbacks.filter(f => f.email === currentUser.email);
      setUserReviews(reviews);
    } catch (error) {
      console.error('Ошибка за��рузки данных пользователя:', error);
    }
  };

  const handleCancelBooking = (bookingId: string) => {
    if (confirm('Вы уверены, что хотите отменить бронирование?')) {
      try {
        bookingService.cancel(currentUser, bookingId);
        loadUserData();
      } catch (error: any) {
        alert(error.message);
      }
    }
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Необходимо войти в систему</p>
          <button
            onClick={() => navigateTo('login')}
            className="bg-orange-500 text-white px-6 py-3 rounded-lg hover:bg-orange-600 transition-colors"
          >
            Войти
          </button>
        </div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-green-100 text-green-700';
      case 'created': return 'bg-yellow-100 text-yellow-700';
      case 'cancelled': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'confirmed': return 'Подтверждено';
      case 'created': return 'Ожидает подтверждения';
      case 'cancelled': return 'Отменено';
      default: return status;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        {/* Шапка профиля */}
        <div className="bg-white rounded-xl shadow-md p-8 mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center">
                <span className="text-orange-500 text-3xl">
                  {currentUser.login.charAt(0).toUpperCase()}
                </span>
              </div>
              <div>
                <h1 className="text-gray-900 mb-1">{currentUser.login}</h1>
                <div className="flex items-center gap-2 text-gray-600">
                  <Mail className="w-4 h-4" />
                  <span>{currentUser.email}</span>
                </div>
                {currentUser.isAdmin && (
                  <span className="inline-block mt-2 bg-purple-100 text-purple-700 text-sm px-3 py-1 rounded-full">
                    Администратор
                  </span>
                )}
              </div>
            </div>
            <div className="flex gap-3">
              <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                <Edit2 className="w-4 h-4" />
                Редактировать профиль
              </button>
              <button
                onClick={onLogout}
                className="px-4 py-2 text-red-600 border border-red-300 rounded-lg hover:bg-red-50 transition-colors"
              >
                Выйти
              </button>
            </div>
          </div>
        </div>

        {/* Вкладки */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
          <div className="flex border-b">
            <button
              onClick={() => setActiveTab('bookings')}
              className={`flex-1 px-6 py-4 transition-colors ${
                activeTab === 'bookings'
                  ? 'bg-orange-500 text-white'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              Мои бронирования ({userBookings.length})
            </button>
            <button
              onClick={() => setActiveTab('favorites')}
              className={`flex-1 px-6 py-4 transition-colors ${
                activeTab === 'favorites'
                  ? 'bg-orange-500 text-white'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              Избранное (0)
            </button>
            <button
              onClick={() => setActiveTab('reviews')}
              className={`flex-1 px-6 py-4 transition-colors ${
                activeTab === 'reviews'
                  ? 'bg-orange-500 text-white'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              Мои отзывы ({userReviews.length})
            </button>
          </div>

          <div className="p-8">
            {/* Бронирования */}
            {activeTab === 'bookings' && (
              <div>
                {userBookings.length > 0 ? (
                  <div className="space-y-4">
                    {userBookings.map((booking) => {
                      const restaurant = restaurantService.getById(booking.restaurantId);
                      if (!restaurant) return null;

                      return (
                        <div key={booking.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <h3 className="text-gray-900">{restaurant.name}</h3>
                                <span className={`text-sm px-3 py-1 rounded-full ${getStatusColor(booking.status)}`}>
                                  {getStatusText(booking.status)}
                                </span>
                              </div>
                              <p className="text-gray-600 text-sm">{restaurant.cuisine}</p>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                            <div className="flex items-center gap-2 text-gray-600">
                              <Calendar className="w-4 h-4 text-orange-500" />
                              <span className="text-sm">
                                {new Date(booking.bookingDate).toLocaleDateString('ru-RU')}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 text-gray-600">
                              <Clock className="w-4 h-4 text-orange-500" />
                              <span className="text-sm">
                                {new Date(booking.bookingDate).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 text-gray-600">
                              <span className="text-sm">Гостей: {booking.guests}</span>
                            </div>
                            <div className="flex items-center gap-2 text-gray-600">
                              <MapPin className="w-4 h-4 text-orange-500" />
                              <span className="text-sm">{restaurant.location}</span>
                            </div>
                          </div>

                          <div className="flex gap-3">
                            <button
                              onClick={() => navigateTo('restaurant-detail', restaurant.id)}
                              className="px-4 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                            >
                              Подробнее о ресторане
                            </button>
                            {booking.status !== 'cancelled' && (
                              <button
                                onClick={() => handleCancelBooking(booking.id)}
                                className="px-4 py-2 text-sm text-red-600 border border-red-300 rounded-lg hover:bg-red-50 transition-colors"
                              >
                                Отменить
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-600 mb-4">У вас пока нет бронирований</p>
                    <button
                      onClick={() => navigateTo('restaurants')}
                      className="bg-orange-500 text-white px-6 py-3 rounded-lg hover:bg-orange-600 transition-colors"
                    >
                      Забронировать стол
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Избранное */}
            {activeTab === 'favorites' && (
              <div className="text-center py-12">
                <Star className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-600 mb-4">У вас пока нет избранных ресторанов</p>
                <button
                  onClick={() => navigateTo('restaurants')}
                  className="bg-orange-500 text-white px-6 py-3 rounded-lg hover:bg-orange-600 transition-colors"
                >
                  Найти рестораны
                </button>
              </div>
            )}

            {/* Отзывы */}
            {activeTab === 'reviews' && (
              <div>
                {userReviews.length > 0 ? (
                  <div className="space-y-4">
                    {userReviews.map((review) => {
                      const restaurant = restaurantService.getById(review.restaurantId);
                      return (
                        <div key={review.id} className="border border-gray-200 rounded-lg p-6">
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <h4 className="text-gray-900 mb-1">{restaurant?.name}</h4>
                              <div className="flex items-center gap-1">
                                {[...Array(review.rating || 0)].map((_, i) => (
                                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                                ))}
                              </div>
                            </div>
                            <span className="text-sm text-gray-500">
                              {new Date(review.createdAt).toLocaleDateString('ru-RU')}
                            </span>
                          </div>
                          <p className="text-gray-600">{review.message}</p>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Star className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-600 mb-4">Вы еще не оставляли отзывов</p>
                    <button
                      onClick={() => navigateTo('restaurants')}
                      className="bg-orange-500 text-white px-6 py-3 rounded-lg hover:bg-orange-600 transition-colors"
                    >
                      Посетить рестораны
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}