import React, { useState, useEffect } from 'react';
import { Calendar, Users, Clock, ArrowLeft, CheckCircle } from '../components/Icons';
import { restaurantService } from '../services/restaurantService';
import { bookingService } from '../services/bookingService';
import type { User, Restaurant } from '../App';

type BookingPageProps = {
  restaurantId: string | null;
  currentUser: User | null;
  navigateTo: (page: string, restaurantId?: string) => void;
};

export function BookingPage({ restaurantId, currentUser, navigateTo }: BookingPageProps) {
  const [selectedRestaurant, setSelectedRestaurant] = useState(restaurantId || '');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [guests, setGuests] = useState(2);
  const [showSuccess, setShowSuccess] = useState(false);
  const [error, setError] = useState('');
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);

  useEffect(() => {
    const allRestaurants = restaurantService.getAll();
    setRestaurants(allRestaurants);
  }, []);

  const restaurant = restaurants.find(r => r.id === selectedRestaurant);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!currentUser) {
      alert('Пожалуйста, войдите в систему для бронирования');
      navigateTo('login');
      return;
    }

    if (!selectedRestaurant || !date || !time) {
      setError('Пожалуйста, заполните все поля');
      return;
    }

    try {
      // Создаем бронирование через сервис
      const bookingDate = new Date(`${date}T${time}`);
      
      bookingService.create(currentUser, {
        restaurantId: selectedRestaurant,
        guests,
        bookingDate: bookingDate.toISOString()
      });

      setShowSuccess(true);
      setTimeout(() => {
        navigateTo('profile');
      }, 2000);
    } catch (error: any) {
      setError(error.message || 'Произошла ошибка при создании бронирования');
    }
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="bg-white rounded-xl shadow-lg p-12 text-center max-w-md">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-12 h-12 text-green-500" />
          </div>
          <h2 className="text-gray-900 mb-4">Бронирование подтверждено!</h2>
          <p className="text-gray-600 mb-6">
            Ваше бронирование успешно создано. Мы отправили подтверждение на вашу почту.
          </p>
          <p className="text-sm text-gray-500">
            Перенаправление в личный кабинет...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        {/* Кнопка назад */}
        <button
          onClick={() => navigateTo(restaurantId ? 'restaurant-detail' : 'restaurants', restaurantId || undefined)}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          Назад
        </button>

        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-gray-900 mb-4">Бронирование стола</h1>
            <p className="text-gray-600">
              Заполните форму для бронирования стола в ресторане
            </p>
          </div>

          <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-lg p-8">
            {/* Сообщение об ошибке */}
            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
                {error}
              </div>
            )}

            {/* Выбор ресторана */}
            <div className="mb-6">
              <label className="block text-gray-700 mb-2">
                Выберите ресторан *
              </label>
              <select
                value={selectedRestaurant}
                onChange={(e) => setSelectedRestaurant(e.target.value)}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
              >
                <option value="">Выберите ресторан</option>
                {restaurants.map(r => (
                  <option key={r.id} value={r.id}>
                    {r.name} - {r.cuisine}
                  </option>
                ))}
              </select>
            </div>

            {/* Информация о выбранном ресторане */}
            {restaurant && (
              <div className="mb-6 p-4 bg-orange-50 rounded-lg border border-orange-200">
                <h3 className="text-gray-900 mb-2">{restaurant.name}</h3>
                <p className="text-sm text-gray-600 mb-2">{restaurant.description}</p>
                <p className="text-sm text-gray-600">📍 {restaurant.location}</p>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              {/* Дата */}
              <div>
                <label className="block text-gray-700 mb-2">
                  <Calendar className="w-4 h-4 inline mr-2" />
                  Дата посещения *
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  min={new Date().toISOString().split('T')[0]}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              {/* Время */}
              <div>
                <label className="block text-gray-700 mb-2">
                  <Clock className="w-4 h-4 inline mr-2" />
                  Время посещения *
                </label>
                <select
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                >
                  <option value="">Выберите время</option>
                  <option value="10:00">10:00</option>
                  <option value="11:00">11:00</option>
                  <option value="12:00">12:00</option>
                  <option value="13:00">13:00</option>
                  <option value="14:00">14:00</option>
                  <option value="15:00">15:00</option>
                  <option value="16:00">16:00</option>
                  <option value="17:00">17:00</option>
                  <option value="18:00">18:00</option>
                  <option value="19:00">19:00</option>
                  <option value="20:00">20:00</option>
                  <option value="21:00">21:00</option>
                  <option value="22:00">22:00</option>
                </select>
              </div>
            </div>

            {/* Количество гостей */}
            <div className="mb-6">
              <label className="block text-gray-700 mb-2">
                <Users className="w-4 h-4 inline mr-2" />
                Количество гостей *
              </label>
              <div className="flex items-center gap-4">
                <button
                  type="button"
                  onClick={() => setGuests(Math.max(1, guests - 1))}
                  className="w-10 h-10 bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  -
                </button>
                <span className="text-xl min-w-[3rem] text-center">{guests}</span>
                <button
                  type="button"
                  onClick={() => setGuests(Math.min(20, guests + 1))}
                  className="w-10 h-10 bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  +
                </button>
                <span className="text-gray-600">гостей</span>
              </div>
            </div>

            {/* Комментарий */}
            <div className="mb-6">
              <label className="block text-gray-700 mb-2">
                Комментарий к бронированию (необязательно)
              </label>
              <textarea
                rows={3}
                placeholder="Особые пожелания, аллергии, предпочтения..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>

            {/* Уведомление для неавторизованных */}
            {!currentUser && (
              <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-sm text-yellow-800">
                  ⚠️ Для завершения бронирования необходимо{' '}
                  <button
                    type="button"
                    onClick={() => navigateTo('login')}
                    className="text-orange-500 underline hover:text-orange-600"
                  >
                    войти в систему
                  </button>
                </p>
              </div>
            )}

            {/* Кнопки */}
            <div className="flex gap-4">
              <button
                type="button"
                onClick={() => navigateTo(restaurantId ? 'restaurant-detail' : 'restaurants', restaurantId || undefined)}
                className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Отмена
              </button>
              <button
                type="submit"
                className="flex-1 px-6 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
              >
                Подтвердить бронирование
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}