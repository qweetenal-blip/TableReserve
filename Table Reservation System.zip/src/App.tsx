import React, { useState, useEffect } from 'react';
import { MainPage } from './pages/MainPage';
import { HelpPage } from './pages/HelpPage';
import { ProfilePage } from './pages/ProfilePage';
import { RestaurantsPage } from './pages/RestaurantsPage';
import { RestaurantDetailPage } from './pages/RestaurantDetailPage';
import { BookingPage } from './pages/BookingPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { AdminPage } from './pages/AdminPage';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { initializeDatabase, AuthAPI } from './api/database';

export type User = {
  id: string;
  login: string;
  email: string;
  avatar?: string;
  isAdmin?: boolean;
};

export type Restaurant = {
  id: string;
  name: string;
  description: string;
  menu: string;
  image: string;
  location: string;
  capacity: number;
  rating: number;
  cuisine: string;
};

export type Booking = {
  id: string;
  userId: string;
  restaurantId: string;
  guests: number;
  bookingDate: string;
  status: 'created' | 'confirmed' | 'cancelled';
  createdAt: string;
};

export type Feedback = {
  id: string;
  name: string;
  email: string;
  message: string;
  restaurantId?: string;
  rating?: number;
  createdAt: string;
};

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>('main');
  const [selectedRestaurantId, setSelectedRestaurantId] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Инициализация базы данных при загрузке приложения
  useEffect(() => {
    // Инициализируем БД
    initializeDatabase();
    
    // Проверяем сохраненную сессию
    const savedUser = AuthAPI.getCurrentUser();
    if (savedUser) {
      setCurrentUser(savedUser);
    }

    console.log('✅ TableReserve запущен');
    console.log('📊 База данных готова к работе');
  }, []);

  const navigateTo = (page: string, restaurantId?: string) => {
    setCurrentPage(page);
    if (restaurantId) {
      setSelectedRestaurantId(restaurantId);
    }
  };

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    navigateTo('profile');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    navigateTo('main');
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'main':
        return <MainPage navigateTo={navigateTo} />;
      case 'restaurants':
        return <RestaurantsPage navigateTo={navigateTo} />;
      case 'restaurant-detail':
        return <RestaurantDetailPage restaurantId={selectedRestaurantId!} navigateTo={navigateTo} />;
      case 'booking':
        return <BookingPage restaurantId={selectedRestaurantId} currentUser={currentUser} navigateTo={navigateTo} />;
      case 'help':
        return <HelpPage />;
      case 'profile':
        return <ProfilePage currentUser={currentUser} navigateTo={navigateTo} onLogout={handleLogout} />;
      case 'login':
        return <LoginPage onLogin={handleLogin} navigateTo={navigateTo} />;
      case 'register':
        return <RegisterPage navigateTo={navigateTo} />;
      case 'admin':
        return <AdminPage currentUser={currentUser} navigateTo={navigateTo} />;
      default:
        return <MainPage navigateTo={navigateTo} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header currentUser={currentUser} navigateTo={navigateTo} onLogout={handleLogout} />
      <main className="flex-1">
        {renderPage()}
      </main>
      <Footer navigateTo={navigateTo} />
    </div>
  );
}