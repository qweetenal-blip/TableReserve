# 🚀 Код-инструкция для запуска TableReserve

## 📌 Шаг 1: Проверка готовности системы

Откройте консоль браузера (F12) и выполните:

```javascript
// Проверить, инициализирована ли база данных
console.log('База данных инициализирована:', 
  localStorage.getItem('tablereserve_initialized') === 'true'
);

// Проверить количество записей в таблицах
console.log('Пользователей:', 
  JSON.parse(localStorage.getItem('tablereserve_users') || '[]').length
);
console.log('Ресторанов:', 
  JSON.parse(localStorage.getItem('tablereserve_restaurants') || '[]').length
);
console.log('Бронирований:', 
  JSON.parse(localStorage.getItem('tablereserve_bookings') || '[]').length
);
console.log('Отзывов:', 
  JSON.parse(localStorage.getItem('tablereserve_feedbacks') || '[]').length
);
```

**Ожидаемый результат:**
```
База данных инициализирована: true
Пользователей: 2
Ресторанов: 6
Бронирований: 2
Отзывов: 2
```

---

## 📌 Шаг 2: Просмотр тестовых данных

### Посмотреть список пользователей:
```javascript
const users = JSON.parse(localStorage.getItem('tablereserve_users'));
console.table(users.map(u => ({
  ID: u.id,
  Login: u.login,
  Email: u.email,
  IsAdmin: u.isAdmin
})));
```

### Посмотреть список ресторанов:
```javascript
const restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants'));
console.table(restaurants.map(r => ({
  ID: r.id,
  Название: r.name,
  Кухня: r.cuisine,
  Рейтинг: r.rating,
  Вместимость: r.capacity
})));
```

### Посмотреть все бронирования:
```javascript
const bookings = JSON.parse(localStorage.getItem('tablereserve_bookings'));
console.table(bookings.map(b => ({
  ID: b.id,
  UserID: b.userId,
  RestaurantID: b.restaurantId,
  Гости: b.guests,
  Дата: new Date(b.bookingDate).toLocaleString('ru-RU'),
  Статус: b.status
})));
```

---

## 📌 Шаг 3: Тест аутентификации через код

### Войти как администратор:
```javascript
// Импортируем функцию входа (в консоли приложения)
const loginData = {
  email: 'admin@tablereserve.ru',
  password: 'admin123'
};

// Проверяем вход
const users = JSON.parse(localStorage.getItem('tablereserve_users'));
const user = users.find(u => u.email === loginData.email && u.password === loginData.password);

if (user) {
  const { password, ...userWithoutPassword } = user;
  localStorage.setItem('tablereserve_current_user', JSON.stringify(userWithoutPassword));
  console.log('✅ Вход выполнен успешно как:', user.login);
  console.log('Роль:', user.isAdmin ? 'Администратор' : 'Пользователь');
  location.reload(); // Перезагрузить страницу
} else {
  console.log('❌ Ошибка входа');
}
```

### Войти как обычный пользователь:
```javascript
const loginData = {
  email: 'user@example.com',
  password: 'user123'
};

const users = JSON.parse(localStorage.getItem('tablereserve_users'));
const user = users.find(u => u.email === loginData.email && u.password === loginData.password);

if (user) {
  const { password, ...userWithoutPassword } = user;
  localStorage.setItem('tablereserve_current_user', JSON.stringify(userWithoutPassword));
  console.log('✅ Вход выполнен как:', user.login);
  location.reload();
} else {
  console.log('❌ Ошибка входа');
}
```

### Проверить текущего пользователя:
```javascript
const currentUser = JSON.parse(localStorage.getItem('tablereserve_current_user'));
if (currentUser) {
  console.log('👤 Текущий пользователь:', currentUser.login);
  console.log('📧 Email:', currentUser.email);
  console.log('🛡️ Администратор:', currentUser.isAdmin ? 'Да' : 'Нет');
} else {
  console.log('❌ Пользователь не авторизован');
}
```

### Выйти из системы:
```javascript
localStorage.removeItem('tablereserve_current_user');
console.log('✅ Вы вышли из системы');
location.reload();
```

---

## 📌 Шаг 4: Создание нового пользователя через код

```javascript
// Функция регистрации нового пользователя
function registerUser(login, email, password) {
  const users = JSON.parse(localStorage.getItem('tablereserve_users') || '[]');
  
  // Проверка на существующий email
  if (users.some(u => u.email === email)) {
    console.log('❌ Пользователь с таким email уже существует');
    return null;
  }
  
  // Создание нового пользователя
  const newUser = {
    id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
    login: login,
    email: email,
    password: password,
    isAdmin: false
  };
  
  users.push(newUser);
  localStorage.setItem('tablereserve_users', JSON.stringify(users));
  
  console.log('✅ Пользователь успешно зарегистрирован:', login);
  return newUser;
}

// Пример использования:
registerUser('newuser', 'newuser@example.com', 'password123');
```

---

## 📌 Шаг 5: Создание бронирования через код

```javascript
// Функция создания бронирования
function createBooking(userId, restaurantId, guests, bookingDate) {
  const bookings = JSON.parse(localStorage.getItem('tablereserve_bookings') || '[]');
  
  const newBooking = {
    id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
    userId: userId,
    restaurantId: restaurantId,
    guests: guests,
    bookingDate: bookingDate,
    status: 'created',
    createdAt: new Date().toISOString()
  };
  
  bookings.push(newBooking);
  localStorage.setItem('tablereserve_bookings', JSON.stringify(bookings));
  
  console.log('✅ Бронирование создано:', newBooking.id);
  return newBooking;
}

// Пример: создать бронирование для текущего пользователя
const currentUser = JSON.parse(localStorage.getItem('tablereserve_current_user'));
if (currentUser) {
  const restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants'));
  const firstRestaurant = restaurants[0];
  
  // Бронирование на завтра в 19:00
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(19, 0, 0, 0);
  
  createBooking(
    currentUser.id,           // ID пользователя
    firstRestaurant.id,       // ID ресторана
    4,                        // Количество гостей
    tomorrow.toISOString()    // Дата бронирования
  );
} else {
  console.log('❌ Необходимо войти в систему');
}
```

---

## 📌 Шаг 6: Создание отзыва через код

```javascript
// Функция создания отзыва
function createFeedback(name, email, message, restaurantId, rating) {
  const feedbacks = JSON.parse(localStorage.getItem('tablereserve_feedbacks') || '[]');
  
  const newFeedback = {
    id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
    name: name,
    email: email,
    message: message,
    restaurantId: restaurantId,
    rating: rating,
    createdAt: new Date().toISOString()
  };
  
  feedbacks.push(newFeedback);
  localStorage.setItem('tablereserve_feedbacks', JSON.stringify(feedbacks));
  
  console.log('✅ Отзыв успешно добавлен');
  return newFeedback;
}

// Пример: добавить отзыв для первого ресторана
const currentUser = JSON.parse(localStorage.getItem('tablereserve_current_user'));
if (currentUser) {
  const restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants'));
  
  createFeedback(
    currentUser.login,                    // Имя
    currentUser.email,                    // Email
    'Отличное место! Очень понравилось!', // Сообщение
    restaurants[0].id,                    // ID ресторана
    5                                     // Рейтинг (1-5)
  );
} else {
  console.log('❌ Необходимо войти в систему');
}
```

---

## 📌 Шаг 7: Управление бронированиями (Админ)

### Подтвердить бронирование:
```javascript
function confirmBooking(bookingId) {
  const bookings = JSON.parse(localStorage.getItem('tablereserve_bookings') || '[]');
  const index = bookings.findIndex(b => b.id === bookingId);
  
  if (index !== -1) {
    bookings[index].status = 'confirmed';
    localStorage.setItem('tablereserve_bookings', JSON.stringify(bookings));
    console.log('✅ Бронирование подтверждено:', bookingId);
  } else {
    console.log('❌ Бронирование не найдено');
  }
}

// Подтвердить первое бронирование
const bookings = JSON.parse(localStorage.getItem('tablereserve_bookings'));
if (bookings.length > 0) {
  confirmBooking(bookings[0].id);
}
```

### Отменить бронирование:
```javascript
function cancelBooking(bookingId) {
  const bookings = JSON.parse(localStorage.getItem('tablereserve_bookings') || '[]');
  const index = bookings.findIndex(b => b.id === bookingId);
  
  if (index !== -1) {
    bookings[index].status = 'cancelled';
    localStorage.setItem('tablereserve_bookings', JSON.stringify(bookings));
    console.log('✅ Бронирование отменено:', bookingId);
  } else {
    console.log('❌ Бронирование не найдено');
  }
}
```

### Удалить бронирование:
```javascript
function deleteBooking(bookingId) {
  let bookings = JSON.parse(localStorage.getItem('tablereserve_bookings') || '[]');
  bookings = bookings.filter(b => b.id !== bookingId);
  localStorage.setItem('tablereserve_bookings', JSON.stringify(bookings));
  console.log('✅ Бронирование удалено:', bookingId);
}
```

---

## 📌 Шаг 8: Управление ресторанами (Админ)

### Добавить новый ресторан:
```javascript
function createRestaurant(name, description, cuisine, location, capacity, rating) {
  const restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants') || '[]');
  
  const newRestaurant = {
    id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
    name: name,
    description: description,
    menu: 'Новое меню скоро будет добавлено',
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4',
    location: location,
    capacity: capacity,
    rating: rating,
    cuisine: cuisine
  };
  
  restaurants.push(newRestaurant);
  localStorage.setItem('tablereserve_restaurants', JSON.stringify(restaurants));
  
  console.log('✅ Ресторан добавлен:', name);
  return newRestaurant;
}

// Пример: добавить новый ресторан
createRestaurant(
  'Новый Ресторан',           // Название
  'Описание ресторана',       // Описание
  'Европейская',              // Кухня
  'ул. Новая, 1',            // Адрес
  80,                         // Вместимость
  4.5                         // Рейтинг
);
```

### Обновить ресторан:
```javascript
function updateRestaurant(restaurantId, updates) {
  const restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants') || '[]');
  const index = restaurants.findIndex(r => r.id === restaurantId);
  
  if (index !== -1) {
    restaurants[index] = { ...restaurants[index], ...updates };
    localStorage.setItem('tablereserve_restaurants', JSON.stringify(restaurants));
    console.log('✅ Ресторан обновлен:', restaurantId);
  } else {
    console.log('❌ Ресторан не найден');
  }
}

// Пример: обновить рейтинг первого ресторана
const restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants'));
if (restaurants.length > 0) {
  updateRestaurant(restaurants[0].id, { rating: 5.0 });
}
```

### Удалить ресторан:
```javascript
function deleteRestaurant(restaurantId) {
  let restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants') || '[]');
  restaurants = restaurants.filter(r => r.id !== restaurantId);
  localStorage.setItem('tablereserve_restaurants', JSON.stringify(restaurants));
  console.log('✅ Ресторан удален:', restaurantId);
}
```

---

## 📌 Шаг 9: Получение статистики

### Общая статистика системы:
```javascript
function getSystemStats() {
  const users = JSON.parse(localStorage.getItem('tablereserve_users') || '[]');
  const restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants') || '[]');
  const bookings = JSON.parse(localStorage.getItem('tablereserve_bookings') || '[]');
  const feedbacks = JSON.parse(localStorage.getItem('tablereserve_feedbacks') || '[]');
  
  const stats = {
    totalUsers: users.length,
    totalRestaurants: restaurants.length,
    totalBookings: bookings.length,
    totalFeedbacks: feedbacks.length,
    activeBookings: bookings.filter(b => b.status === 'confirmed').length,
    pendingBookings: bookings.filter(b => b.status === 'created').length,
    cancelledBookings: bookings.filter(b => b.status === 'cancelled').length,
    averageRating: feedbacks.reduce((acc, f) => acc + (f.rating || 0), 0) / feedbacks.length || 0
  };
  
  console.log('📊 Статистика системы:');
  console.table(stats);
  return stats;
}

// Получить статистику
getSystemStats();
```

### Статистика пользователя:
```javascript
function getUserStats(userId) {
  const bookings = JSON.parse(localStorage.getItem('tablereserve_bookings') || '[]');
  const feedbacks = JSON.parse(localStorage.getItem('tablereserve_feedbacks') || '[]');
  const user = JSON.parse(localStorage.getItem('tablereserve_users') || '[]').find(u => u.id === userId);
  
  const userBookings = bookings.filter(b => b.userId === userId);
  const userFeedbacks = feedbacks.filter(f => f.email === user?.email);
  
  const stats = {
    totalBookings: userBookings.length,
    activeBookings: userBookings.filter(b => b.status === 'confirmed').length,
    totalFeedbacks: userFeedbacks.length
  };
  
  console.log(`📊 Статистика пользователя ${user?.login}:`);
  console.table(stats);
  return stats;
}

// Статистика текущего пользователя
const currentUser = JSON.parse(localStorage.getItem('tablereserve_current_user'));
if (currentUser) {
  getUserStats(currentUser.id);
}
```

---

## 📌 Шаг 10: Поиск и фильтрация

### Поиск ресторанов:
```javascript
function searchRestaurants(query) {
  const restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants') || '[]');
  const lowerQuery = query.toLowerCase();
  
  const results = restaurants.filter(r => 
    r.name.toLowerCase().includes(lowerQuery) ||
    r.description.toLowerCase().includes(lowerQuery) ||
    r.cuisine.toLowerCase().includes(lowerQuery) ||
    r.location.toLowerCase().includes(lowerQuery)
  );
  
  console.log(`🔍 Найдено ресторанов: ${results.length}`);
  console.table(results.map(r => ({
    Название: r.name,
    Кухня: r.cuisine,
    Адрес: r.location,
    Рейтинг: r.rating
  })));
  
  return results;
}

// Поиск итальянских ресторанов
searchRestaurants('итальянск');
```

### Фильтрация по кухне:
```javascript
function filterByCuisine(cuisine) {
  const restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants') || '[]');
  const results = restaurants.filter(r => r.cuisine === cuisine);
  
  console.log(`🍽️ ${cuisine} ресторанов: ${results.length}`);
  console.table(results.map(r => ({ Название: r.name, Рейтинг: r.rating })));
  
  return results;
}

// Найти все японские рестораны
filterByCuisine('Японская');
```

### Фильтрация по рейтингу:
```javascript
function filterByRating(minRating) {
  const restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants') || '[]');
  const results = restaurants.filter(r => r.rating >= minRating);
  
  console.log(`⭐ Ресторанов с рейтингом >= ${minRating}: ${results.length}`);
  console.table(results.map(r => ({ 
    Название: r.name, 
    Рейтинг: r.rating,
    Кухня: r.cuisine 
  })));
  
  return results;
}

// Рестораны с рейтингом 4.8+
filterByRating(4.8);
```

---

## 📌 Шаг 11: Сброс и переинициализация базы данных

### Полный сброс БД:
```javascript
// ВНИМАНИЕ: Это удалит ВСЕ данные!
function resetDatabase() {
  const confirm = prompt('Вы уверены? Введите "YES" для подтверждения:');
  if (confirm === 'YES') {
    localStorage.removeItem('tablereserve_users');
    localStorage.removeItem('tablereserve_restaurants');
    localStorage.removeItem('tablereserve_bookings');
    localStorage.removeItem('tablereserve_feedbacks');
    localStorage.removeItem('tablereserve_current_user');
    localStorage.removeItem('tablereserve_initialized');
    
    console.log('🔄 База данных очищена');
    console.log('🔄 Перезагрузите страницу для переинициализации');
    
    setTimeout(() => location.reload(), 2000);
  } else {
    console.log('❌ Сброс отменен');
  }
}

// Использование:
// resetDatabase();
```

### Экспорт данных:
```javascript
function exportData() {
  const data = {
    users: JSON.parse(localStorage.getItem('tablereserve_users') || '[]'),
    restaurants: JSON.parse(localStorage.getItem('tablereserve_restaurants') || '[]'),
    bookings: JSON.parse(localStorage.getItem('tablereserve_bookings') || '[]'),
    feedbacks: JSON.parse(localStorage.getItem('tablereserve_feedbacks') || '[]')
  };
  
  const jsonData = JSON.stringify(data, null, 2);
  
  // Скачать файл
  const blob = new Blob([jsonData], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'tablereserve_backup.json';
  a.click();
  
  console.log('✅ Данные экспортированы');
}

// Экспорт данных
exportData();
```

---

## 📌 Шаг 12: Массовое создание тестовых данных

### Создать несколько тестовых пользователей:
```javascript
function createTestUsers(count) {
  for (let i = 1; i <= count; i++) {
    registerUser(
      `testuser${i}`,
      `testuser${i}@example.com`,
      'password123'
    );
  }
  console.log(`✅ Создано ${count} тестовых пользователей`);
}

// Создать 5 тестовых пользователей
createTestUsers(5);
```

### Создать несколько тестовых бронирований:
```javascript
function createTestBookings(count) {
  const currentUser = JSON.parse(localStorage.getItem('tablereserve_current_user'));
  if (!currentUser) {
    console.log('❌ Необходимо войти в систему');
    return;
  }
  
  const restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants'));
  
  for (let i = 1; i <= count; i++) {
    const randomRestaurant = restaurants[Math.floor(Math.random() * restaurants.length)];
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + i);
    futureDate.setHours(19 + (i % 4), 0, 0, 0);
    
    createBooking(
      currentUser.id,
      randomRestaurant.id,
      2 + (i % 6),
      futureDate.toISOString()
    );
  }
  
  console.log(`✅ Создано ${count} тестовых бронирований`);
}

// Создать 10 бронирований
createTestBookings(10);
```

---

## 📌 Шаг 13: Проверка прав доступа

### Проверить права текущего пользователя:
```javascript
function checkPermissions() {
  const currentUser = JSON.parse(localStorage.getItem('tablereserve_current_user'));
  
  if (!currentUser) {
    console.log('❌ Пользователь не авторизован');
    console.log('Доступные права: только просмотр каталога');
    return;
  }
  
  console.log(`👤 Пользователь: ${currentUser.login}`);
  console.log(`🛡️ Роль: ${currentUser.isAdmin ? 'Администратор' : 'Пользователь'}`);
  
  const permissions = {
    'Просмотр ресторанов': true,
    'Создание бронирований': true,
    'Управление своими бронированиями': true,
    'Оставление отзывов': true,
    'Управление ресторанами': currentUser.isAdmin,
    'Модерация бронирований': currentUser.isAdmin,
    'Управление пользователями': currentUser.isAdmin,
    'Доступ к аналитике': currentUser.isAdmin
  };
  
  console.log('\n📋 Доступные права:');
  console.table(permissions);
}

// Проверить права
checkPermissions();
```

---

## 📌 Полезные команды для тестирования

### Быстрое переключение между пользователями:
```javascript
// Войти как админ
localStorage.setItem('tablereserve_current_user', JSON.stringify({
  id: '1',
  login: 'admin',
  email: 'admin@tablereserve.ru',
  isAdmin: true
}));
location.reload();

// Войти как пользователь
localStorage.setItem('tablereserve_current_user', JSON.stringify({
  id: '2',
  login: 'user',
  email: 'user@example.com',
  isAdmin: false
}));
location.reload();

// Выйти
localStorage.removeItem('tablereserve_current_user');
location.reload();
```

### Просмотр всех данных одной командой:
```javascript
console.log('=== ПОЛНЫЙ ДАМП БАЗЫ ДАННЫХ ===\n');
console.log('👥 ПОЛЬЗОВАТЕЛИ:');
console.table(JSON.parse(localStorage.getItem('tablereserve_users')));
console.log('\n🍽️ РЕСТОРАНЫ:');
console.table(JSON.parse(localStorage.getItem('tablereserve_restaurants')));
console.log('\n📅 БРОНИРОВАНИЯ:');
console.table(JSON.parse(localStorage.getItem('tablereserve_bookings')));
console.log('\n💬 ОТЗЫВЫ:');
console.table(JSON.parse(localStorage.getItem('tablereserve_feedbacks')));
```

---

## 🎯 Готовые сценарии для демонстрации

### Сценарий 1: Полный цикл пользователя
```javascript
// 1. Регистрация
registerUser('demo', 'demo@example.com', 'demo123');

// 2. Вход
const users = JSON.parse(localStorage.getItem('tablereserve_users'));
const demoUser = users.find(u => u.email === 'demo@example.com');
localStorage.setItem('tablereserve_current_user', JSON.stringify(demoUser));

// 3. Создание бронирования
const tomorrow = new Date();
tomorrow.setDate(tomorrow.getDate() + 1);
tomorrow.setHours(20, 0, 0, 0);
const restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants'));
createBooking(demoUser.id, restaurants[0].id, 2, tomorrow.toISOString());

// 4. Добавление отзыва
createFeedback(demoUser.login, demoUser.email, 'Отличный сервис!', restaurants[0].id, 5);

console.log('✅ Демонстрация завершена!');
location.reload();
```

### Сценарий 2: Работа администратора
```javascript
// Войти как админ
const users = JSON.parse(localStorage.getItem('tablereserve_users'));
const admin = users.find(u => u.isAdmin);
localStorage.setItem('tablereserve_current_user', JSON.stringify(admin));

// Просмотр статистики
getSystemStats();

// Подтверждение всех ожидающих бронирований
const bookings = JSON.parse(localStorage.getItem('tablereserve_bookings'));
bookings.filter(b => b.status === 'created').forEach(b => {
  confirmBooking(b.id);
});

console.log('✅ Все бронирования подтверждены');
location.reload();
```

---

## ✅ Чек-лист для проверки

Скопируйте и выполните для полной проверки:

```javascript
console.log('🔍 ПРОВЕРКА СИСТЕМЫ TABLERESERVE\n');

// 1. База данных
const dbOk = localStorage.getItem('tablereserve_initialized') === 'true';
console.log(`${dbOk ? '✅' : '❌'} База данных инициализирована`);

// 2. Тестовые данные
const hasUsers = JSON.parse(localStorage.getItem('tablereserve_users') || '[]').length >= 2;
const hasRestaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants') || '[]').length >= 6;
console.log(`${hasUsers ? '✅' : '❌'} Пользователи загружены`);
console.log(`${hasRestaurants ? '✅' : '❌'} Рестораны загружены`);

// 3. Аутентификация
const currentUser = JSON.parse(localStorage.getItem('tablereserve_current_user'));
console.log(`${currentUser ? '✅' : '⚠️'} Пользователь ${currentUser ? 'авторизован' : 'не авторизован'}`);

// 4. Итого
console.log('\n📊 СТАТИСТИКА:');
getSystemStats();

console.log('\n✨ Проверка завершена!');
```

---

**Готово! Используйте эти команды для полного тестирования системы TableReserve.**

