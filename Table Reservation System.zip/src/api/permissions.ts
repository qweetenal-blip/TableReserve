/**
 * Система управления ролями и правами доступа
 */

import { User } from '../App';

// Роли в системе
export enum UserRole {
  GUEST = 'guest',           // Неавторизованный пользователь
  USER = 'user',             // Зарегистрированный пользователь
  ADMIN = 'admin'            // Администратор
}

// Права доступа
export enum Permission {
  // Рестораны
  VIEW_RESTAURANTS = 'view_restaurants',
  CREATE_RESTAURANT = 'create_restaurant',
  UPDATE_RESTAURANT = 'update_restaurant',
  DELETE_RESTAURANT = 'delete_restaurant',
  
  // Бронирования
  VIEW_OWN_BOOKINGS = 'view_own_bookings',
  VIEW_ALL_BOOKINGS = 'view_all_bookings',
  CREATE_BOOKING = 'create_booking',
  UPDATE_OWN_BOOKING = 'update_own_booking',
  UPDATE_ALL_BOOKINGS = 'update_all_bookings',
  CANCEL_OWN_BOOKING = 'cancel_own_booking',
  CANCEL_ALL_BOOKINGS = 'cancel_all_bookings',
  DELETE_BOOKING = 'delete_booking',
  
  // Отзывы
  VIEW_FEEDBACKS = 'view_feedbacks',
  CREATE_FEEDBACK = 'create_feedback',
  UPDATE_FEEDBACK = 'update_feedback',
  DELETE_FEEDBACK = 'delete_feedback',
  
  // Пользователи
  VIEW_USERS = 'view_users',
  CREATE_USER = 'create_user',
  UPDATE_USER = 'update_user',
  DELETE_USER = 'delete_user',
  
  // Админ-панель
  ACCESS_ADMIN_PANEL = 'access_admin_panel',
  VIEW_ANALYTICS = 'view_analytics'
}

// Права для каждой роли
const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  [UserRole.GUEST]: [
    Permission.VIEW_RESTAURANTS,
    Permission.VIEW_FEEDBACKS
  ],
  
  [UserRole.USER]: [
    Permission.VIEW_RESTAURANTS,
    Permission.VIEW_FEEDBACKS,
    Permission.VIEW_OWN_BOOKINGS,
    Permission.CREATE_BOOKING,
    Permission.UPDATE_OWN_BOOKING,
    Permission.CANCEL_OWN_BOOKING,
    Permission.CREATE_FEEDBACK
  ],
  
  [UserRole.ADMIN]: [
    // Рестораны
    Permission.VIEW_RESTAURANTS,
    Permission.CREATE_RESTAURANT,
    Permission.UPDATE_RESTAURANT,
    Permission.DELETE_RESTAURANT,
    
    // Бронирования
    Permission.VIEW_OWN_BOOKINGS,
    Permission.VIEW_ALL_BOOKINGS,
    Permission.CREATE_BOOKING,
    Permission.UPDATE_OWN_BOOKING,
    Permission.UPDATE_ALL_BOOKINGS,
    Permission.CANCEL_OWN_BOOKING,
    Permission.CANCEL_ALL_BOOKINGS,
    Permission.DELETE_BOOKING,
    
    // Отзывы
    Permission.VIEW_FEEDBACKS,
    Permission.CREATE_FEEDBACK,
    Permission.UPDATE_FEEDBACK,
    Permission.DELETE_FEEDBACK,
    
    // Пользователи
    Permission.VIEW_USERS,
    Permission.CREATE_USER,
    Permission.UPDATE_USER,
    Permission.DELETE_USER,
    
    // Админ-панель
    Permission.ACCESS_ADMIN_PANEL,
    Permission.VIEW_ANALYTICS
  ]
};

/**
 * Определить роль пользователя
 */
export function getUserRole(user: User | null): UserRole {
  if (!user) {
    return UserRole.GUEST;
  }
  
  if (user.isAdmin) {
    return UserRole.ADMIN;
  }
  
  return UserRole.USER;
}

/**
 * Проверить, есть ли у пользователя определенное право
 */
export function hasPermission(user: User | null, permission: Permission): boolean {
  const role = getUserRole(user);
  return ROLE_PERMISSIONS[role].includes(permission);
}

/**
 * Проверить, есть ли у пользователя хотя бы одно из прав
 */
export function hasAnyPermission(user: User | null, permissions: Permission[]): boolean {
  return permissions.some(permission => hasPermission(user, permission));
}

/**
 * Проверить, есть ли у пользователя все права
 */
export function hasAllPermissions(user: User | null, permissions: Permission[]): boolean {
  return permissions.every(permission => hasPermission(user, permission));
}

/**
 * Получить все права пользователя
 */
export function getUserPermissions(user: User | null): Permission[] {
  const role = getUserRole(user);
  return ROLE_PERMISSIONS[role];
}

/**
 * Проверить, является ли пользователь администратором
 */
export function isAdmin(user: User | null): boolean {
  return getUserRole(user) === UserRole.ADMIN;
}

/**
 * Проверить, является ли пользователь зарегистрированным
 */
export function isAuthenticated(user: User | null): boolean {
  return user !== null;
}

/**
 * Проверить, является ли пользователь гостем
 */
export function isGuest(user: User | null): boolean {
  return getUserRole(user) === UserRole.GUEST;
}

/**
 * Защищенный вызов функции с проверкой прав
 */
export function withPermission<T>(
  user: User | null,
  permission: Permission,
  fn: () => T,
  errorMessage?: string
): T {
  if (!hasPermission(user, permission)) {
    throw new Error(errorMessage || 'Недостаточно прав для выполнения операции');
  }
  
  return fn();
}

/**
 * Middleware для проверки прав перед выполнением операции
 */
export function requirePermission(user: User | null, permission: Permission): void {
  if (!hasPermission(user, permission)) {
    throw new Error(`Требуется право: ${permission}`);
  }
}

/**
 * Middleware для проверки аутентификации
 */
export function requireAuthentication(user: User | null): void {
  if (!isAuthenticated(user)) {
    throw new Error('Необходимо войти в систему');
  }
}

/**
 * Middleware для проверки прав администратора
 */
export function requireAdmin(user: User | null): void {
  if (!isAdmin(user)) {
    throw new Error('Требуются права администратора');
  }
}
