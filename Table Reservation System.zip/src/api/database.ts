/**
 * Локальная база данных на основе LocalStorage
 * Эмулирует работу PostgreSQL/MySQL с CRUD операциями
 */

import { User, Restaurant, Booking, Feedback } from '../App';
import { mockRestaurants, mockUsers, mockBookings, mockFeedbacks } from '../data/mockData';

// Ключи для LocalStorage
const STORAGE_KEYS = {
  USERS: 'tablereserve_users',
  RESTAURANTS: 'tablereserve_restaurants',
  BOOKINGS: 'tablereserve_bookings',
  FEEDBACKS: 'tablereserve_feedbacks',
  CURRENT_USER: 'tablereserve_current_user',
  INITIALIZED: 'tablereserve_initialized'
};

/**
 * Инициализация базы данных начальными данными
 */
export function initializeDatabase(): void {
  const initialized = localStorage.getItem(STORAGE_KEYS.INITIALIZED);
  
  if (!initialized) {
    // Добавляем пароли к пользователям для тестирования
    const usersWithPasswords = [
      { ...mockUsers[0], password: 'admin123' }, // admin@tablereserve.ru
      { ...mockUsers[1], password: 'user123' }    // user@example.com
    ];
    
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(usersWithPasswords));
    localStorage.setItem(STORAGE_KEYS.RESTAURANTS, JSON.stringify(mockRestaurants));
    localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(mockBookings));
    localStorage.setItem(STORAGE_KEYS.FEEDBACKS, JSON.stringify(mockFeedbacks));
    localStorage.setItem(STORAGE_KEYS.INITIALIZED, 'true');
    
    console.log('✅ База данных инициализирована');
  }
}

/**
 * Получение данных из LocalStorage
 */
function getFromStorage<T>(key: string): T[] {
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

/**
 * Сохранение данных в LocalStorage
 */
function saveToStorage<T>(key: string, data: T[]): void {
  localStorage.setItem(key, JSON.stringify(data));
}

/**
 * Генерация уникального ID
 */
function generateId(): string {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

// ============ USERS API ============

export const UsersAPI = {
  /**
   * Получить всех пользователей (только для админа)
   */
  getAll(): User[] {
    const users = getFromStorage<any>(STORAGE_KEYS.USERS);
    return users.map(({ password, ...user }) => user);
  },

  /**
   * Получить пользователя по ID
   */
  getById(id: string): User | null {
    const users = getFromStorage<any>(STORAGE_KEYS.USERS);
    const user = users.find(u => u.id === id);
    if (user) {
      const { password, ...userWithoutPassword } = user;
      return userWithoutPassword;
    }
    return null;
  },

  /**
   * Создать нового пользователя
   */
  create(userData: { login: string; email: string; password: string }): User {
    const users = getFromStorage<any>(STORAGE_KEYS.USERS);
    
    // Проверка на существующий email
    if (users.some(u => u.email === userData.email)) {
      throw new Error('Пользователь с таким email уже существует');
    }
    
    const newUser = {
      id: generateId(),
      login: userData.login,
      email: userData.email,
      password: userData.password,
      isAdmin: false
    };
    
    users.push(newUser);
    saveToStorage(STORAGE_KEYS.USERS, users);
    
    const { password, ...userWithoutPassword } = newUser;
    return userWithoutPassword;
  },

  /**
   * Обновить пользователя
   */
  update(id: string, updates: Partial<User>): User | null {
    const users = getFromStorage<any>(STORAGE_KEYS.USERS);
    const index = users.findIndex(u => u.id === id);
    
    if (index !== -1) {
      users[index] = { ...users[index], ...updates };
      saveToStorage(STORAGE_KEYS.USERS, users);
      
      const { password, ...userWithoutPassword } = users[index];
      return userWithoutPassword;
    }
    
    return null;
  },

  /**
   * Удалить пользователя
   */
  delete(id: string): boolean {
    const users = getFromStorage<any>(STORAGE_KEYS.USERS);
    const filtered = users.filter(u => u.id !== id);
    
    if (filtered.length < users.length) {
      saveToStorage(STORAGE_KEYS.USERS, filtered);
      return true;
    }
    
    return false;
  },

  /**
   * Аутентификация пользователя
   */
  authenticate(email: string, password: string): User | null {
    const users = getFromStorage<any>(STORAGE_KEYS.USERS);
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
      const { password: _, ...userWithoutPassword } = user;
      return userWithoutPassword;
    }
    
    return null;
  }
};

// ============ RESTAURANTS API ============

export const RestaurantsAPI = {
  /**
   * Получить все рестораны
   */
  getAll(): Restaurant[] {
    return getFromStorage<Restaurant>(STORAGE_KEYS.RESTAURANTS);
  },

  /**
   * Получить ресторан по ID
   */
  getById(id: string): Restaurant | null {
    const restaurants = getFromStorage<Restaurant>(STORAGE_KEYS.RESTAURANTS);
    return restaurants.find(r => r.id === id) || null;
  },

  /**
   * Создать новый ресторан (только для админа)
   */
  create(restaurantData: Omit<Restaurant, 'id'>): Restaurant {
    const restaurants = getFromStorage<Restaurant>(STORAGE_KEYS.RESTAURANTS);
    
    const newRestaurant: Restaurant = {
      id: generateId(),
      ...restaurantData
    };
    
    restaurants.push(newRestaurant);
    saveToStorage(STORAGE_KEYS.RESTAURANTS, restaurants);
    
    return newRestaurant;
  },

  /**
   * Обновить ресторан (только для админа)
   */
  update(id: string, updates: Partial<Restaurant>): Restaurant | null {
    const restaurants = getFromStorage<Restaurant>(STORAGE_KEYS.RESTAURANTS);
    const index = restaurants.findIndex(r => r.id === id);
    
    if (index !== -1) {
      restaurants[index] = { ...restaurants[index], ...updates };
      saveToStorage(STORAGE_KEYS.RESTAURANTS, restaurants);
      return restaurants[index];
    }
    
    return null;
  },

  /**
   * Удалить ресторан (только для админа)
   */
  delete(id: string): boolean {
    const restaurants = getFromStorage<Restaurant>(STORAGE_KEYS.RESTAURANTS);
    const filtered = restaurants.filter(r => r.id !== id);
    
    if (filtered.length < restaurants.length) {
      saveToStorage(STORAGE_KEYS.RESTAURANTS, filtered);
      return true;
    }
    
    return false;
  },

  /**
   * Поиск ресторанов
   */
  search(query: string): Restaurant[] {
    const restaurants = getFromStorage<Restaurant>(STORAGE_KEYS.RESTAURANTS);
    const lowerQuery = query.toLowerCase();
    
    return restaurants.filter(r => 
      r.name.toLowerCase().includes(lowerQuery) ||
      r.description.toLowerCase().includes(lowerQuery) ||
      r.cuisine.toLowerCase().includes(lowerQuery) ||
      r.location.toLowerCase().includes(lowerQuery)
    );
  }
};

// ============ BOOKINGS API ============

export const BookingsAPI = {
  /**
   * Получить все бронирования (только для админа)
   */
  getAll(): Booking[] {
    return getFromStorage<Booking>(STORAGE_KEYS.BOOKINGS);
  },

  /**
   * Получить бронирования пользователя
   */
  getByUserId(userId: string): Booking[] {
    const bookings = getFromStorage<Booking>(STORAGE_KEYS.BOOKINGS);
    return bookings.filter(b => b.userId === userId);
  },

  /**
   * Получить бронирования ресторана
   */
  getByRestaurantId(restaurantId: string): Booking[] {
    const bookings = getFromStorage<Booking>(STORAGE_KEYS.BOOKINGS);
    return bookings.filter(b => b.restaurantId === restaurantId);
  },

  /**
   * Создать новое бронирование
   */
  create(bookingData: Omit<Booking, 'id' | 'createdAt' | 'status'>): Booking {
    const bookings = getFromStorage<Booking>(STORAGE_KEYS.BOOKINGS);
    
    const newBooking: Booking = {
      id: generateId(),
      ...bookingData,
      status: 'created',
      createdAt: new Date().toISOString()
    };
    
    bookings.push(newBooking);
    saveToStorage(STORAGE_KEYS.BOOKINGS, bookings);
    
    return newBooking;
  },

  /**
   * Обновить бронирование
   */
  update(id: string, updates: Partial<Booking>): Booking | null {
    const bookings = getFromStorage<Booking>(STORAGE_KEYS.BOOKINGS);
    const index = bookings.findIndex(b => b.id === id);
    
    if (index !== -1) {
      bookings[index] = { ...bookings[index], ...updates };
      saveToStorage(STORAGE_KEYS.BOOKINGS, bookings);
      return bookings[index];
    }
    
    return null;
  },

  /**
   * Отменить бронирование
   */
  cancel(id: string): Booking | null {
    return this.update(id, { status: 'cancelled' });
  },

  /**
   * Удалить бронирование (только для админа)
   */
  delete(id: string): boolean {
    const bookings = getFromStorage<Booking>(STORAGE_KEYS.BOOKINGS);
    const filtered = bookings.filter(b => b.id !== id);
    
    if (filtered.length < bookings.length) {
      saveToStorage(STORAGE_KEYS.BOOKINGS, filtered);
      return true;
    }
    
    return false;
  }
};

// ============ FEEDBACKS API ============

export const FeedbacksAPI = {
  /**
   * Получить все отзывы
   */
  getAll(): Feedback[] {
    return getFromStorage<Feedback>(STORAGE_KEYS.FEEDBACKS);
  },

  /**
   * Получить отзывы для ресторана
   */
  getByRestaurantId(restaurantId: string): Feedback[] {
    const feedbacks = getFromStorage<Feedback>(STORAGE_KEYS.FEEDBACKS);
    return feedbacks.filter(f => f.restaurantId === restaurantId);
  },

  /**
   * Создать новый отзыв
   */
  create(feedbackData: Omit<Feedback, 'id' | 'createdAt'>): Feedback {
    const feedbacks = getFromStorage<Feedback>(STORAGE_KEYS.FEEDBACKS);
    
    const newFeedback: Feedback = {
      id: generateId(),
      ...feedbackData,
      createdAt: new Date().toISOString()
    };
    
    feedbacks.push(newFeedback);
    saveToStorage(STORAGE_KEYS.FEEDBACKS, feedbacks);
    
    return newFeedback;
  },

  /**
   * Обновить отзыв (только для админа)
   */
  update(id: string, updates: Partial<Feedback>): Feedback | null {
    const feedbacks = getFromStorage<Feedback>(STORAGE_KEYS.FEEDBACKS);
    const index = feedbacks.findIndex(f => f.id === id);
    
    if (index !== -1) {
      feedbacks[index] = { ...feedbacks[index], ...updates };
      saveToStorage(STORAGE_KEYS.FEEDBACKS, feedbacks);
      return feedbacks[index];
    }
    
    return null;
  },

  /**
   * Удалить отзыв (только для админа)
   */
  delete(id: string): boolean {
    const feedbacks = getFromStorage<Feedback>(STORAGE_KEYS.FEEDBACKS);
    const filtered = feedbacks.filter(f => f.id !== id);
    
    if (filtered.length < feedbacks.length) {
      saveToStorage(STORAGE_KEYS.FEEDBACKS, filtered);
      return true;
    }
    
    return false;
  }
};

// ============ AUTHENTICATION ============

export const AuthAPI = {
  /**
   * Вход в систему
   */
  login(email: string, password: string): User | null {
    const user = UsersAPI.authenticate(email, password);
    
    if (user) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
      return user;
    }
    
    return null;
  },

  /**
   * Регистрация
   */
  register(userData: { login: string; email: string; password: string }): User {
    const user = UsersAPI.create(userData);
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    return user;
  },

  /**
   * Выход из системы
   */
  logout(): void {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  },

  /**
   * Получить текущего пользователя
   */
  getCurrentUser(): User | null {
    const userData = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return userData ? JSON.parse(userData) : null;
  }
};

// ============ ANALYTICS ============

export const AnalyticsAPI = {
  /**
   * Получить общую статистику (для админ-панели)
   */
  getStats() {
    const users = UsersAPI.getAll();
    const restaurants = RestaurantsAPI.getAll();
    const bookings = BookingsAPI.getAll();
    const feedbacks = FeedbacksAPI.getAll();

    return {
      totalUsers: users.length,
      totalRestaurants: restaurants.length,
      totalBookings: bookings.length,
      totalFeedbacks: feedbacks.length,
      activeBookings: bookings.filter(b => b.status === 'confirmed').length,
      pendingBookings: bookings.filter(b => b.status === 'created').length,
      cancelledBookings: bookings.filter(b => b.status === 'cancelled').length,
      averageRating: feedbacks.reduce((acc, f) => acc + (f.rating || 0), 0) / feedbacks.length || 0
    };
  },

  /**
   * Получить последние действия
   */
  getRecentActivity(limit: number = 10) {
    const bookings = BookingsAPI.getAll();
    const feedbacks = FeedbacksAPI.getAll();

    const activities = [
      ...bookings.map(b => ({
        type: 'booking' as const,
        date: b.createdAt,
        data: b
      })),
      ...feedbacks.map(f => ({
        type: 'feedback' as const,
        date: f.createdAt,
        data: f
      }))
    ];

    return activities
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, limit);
  }
};
