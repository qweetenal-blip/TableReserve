# 🧭 Навигация по TableReserve

## 📖 Какой файл открыть?

```
┌─────────────────────────────────────────────────┐
│  🎯 ВЫБЕРИТЕ ВАШУ ЦЕЛЬ                          │
└─────────────────────────────────────────────────┘

🚀 ХОЧУ БЫСТРО ЗАПУСТИТЬ
   └─► START_HERE.md (30 секунд)

📋 НУЖНА ИНСТРУКЦИЯ ДЛЯ СДАЧИ
   └─► LAUNCH_INSTRUCTIONS.md

💻 ХОЧУ ПРИМЕРЫ КОДА
   └─► QUICK_START_CODE.md

📚 ХОЧУ ПОДРОБНУЮ НАСТРОЙКУ
   └─► SETUP_GUIDE.md

✅ НУЖЕН ЧЕК-ЛИСТ ПРОВЕРКИ
   └─► CHECKLIST.md

📊 ХОЧУ РЕЗЮМЕ ПРОЕКТА
   └─► PROJECT_SUMMARY.md

📖 ПОЛНАЯ ДОКУМЕНТАЦИЯ
   └─► README.md

🧭 ЭТО ЧТО ТАКОЕ?
   └─► NAVIGATION_GUIDE.md (вы здесь)
```

---

## 🗺️ Карта проекта

### 📂 Директории

```
TableReserve/
│
├── 📁 api/                  ← Работа с данными
│   ├── database.ts          (CRUD операции)
│   └── permissions.ts       (Система прав)
│
├── 📁 services/             ← Бизнес-логика
│   ├── authService.ts       (Вход/Регистрация)
│   ├── restaurantService.ts (Рестораны)
│   ├── bookingService.ts    (Бронирования)
│   ├── feedbackService.ts   (Отзывы)
│   └── adminService.ts      (Админ-функции)
│
├── 📁 pages/                ← Страницы сайта
│   ├── MainPage.tsx         (/)
│   ├── RestaurantsPage.tsx  (/restaurants)
│   ├── RestaurantDetailPage.tsx
│   ├── BookingPage.tsx      (/booking)
│   ├── ProfilePage.tsx      (/profile)
│   ├── AdminPage.tsx        (/admin)
│   ├── LoginPage.tsx        (/login)
│   ├── RegisterPage.tsx     (/register)
│   └── HelpPage.tsx         (/help)
│
├── 📁 components/           ← Компоненты
│   ├── Header.tsx
│   ├── Footer.tsx
│   ├── RestaurantCard.tsx
│   └── ui/                  (UI библиотека)
│
├── 📁 data/
│   └── mockData.ts          ← Начальные данные
│
├── 📄 App.tsx               ← Главный компонент
│
└── 📚 Документация          ← Инструкции
    ├── START_HERE.md        ⭐ Начните здесь
    ├── LAUNCH_INSTRUCTIONS.md
    ├── QUICK_START_CODE.md
    ├── SETUP_GUIDE.md
    ├── CHECKLIST.md
    ├── PROJECT_SUMMARY.md
    ├── README.md
    └── NAVIGATION_GUIDE.md  (вы здесь)
```

---

## 🎬 Сценарии использования

### 🟢 Сценарий 1: Первый запуск (вы здесь впервые)

```
1. Откройте START_HERE.md
   ↓
2. Скопируйте код проверки в консоль
   ↓
3. Войдите через тестовый аккаунт
   ↓
4. Протестируйте основные функции
```

### 🔵 Сценарий 2: Сдача проекта

```
1. Откройте CHECKLIST.md
   ↓
2. Пройдите все пункты
   ↓
3. Откройте LAUNCH_INSTRUCTIONS.md
   ↓
4. Следуйте инструкциям для демо
```

### 🟡 Сценарий 3: Изучение кода

```
1. Откройте PROJECT_SUMMARY.md (обзор)
   ↓
2. Откройте README.md (детали)
   ↓
3. Изучите /api и /services
   ↓
4. Посмотрите /pages
```

### 🔴 Сценарий 4: Тестирование функций

```
1. Откройте QUICK_START_CODE.md
   ↓
2. Скопируйте нужную функцию
   ↓
3. Выполните в консоли (F12)
   ↓
4. Проверьте результат
```

---

## 📱 Навигация по сайту

### Главная страница (/)
```
┌──────────────────────────────┐
│  🏠 ГЛАВНАЯ                  │
├──────────────────────────────┤
│  • Hero секция               │
│  • Преимущества (3 блока)    │
│  • Популярные рестораны (3)  │
│  • Как забронировать (4 шага)│
└──────────────────────────────┘
         ↓
    [Выбрать ресторан]
         ↓
    Каталог ресторанов
```

### Каталог ресторанов (/restaurants)
```
┌──────────────────────────────┐
│  🍽️ РЕСТОРАНЫ                │
├──────────────────────────────┤
│  🔍 Поиск                    │
│  🎛️ Фильтр (по кухне)        │
│  📋 Список (6 ресторанов)    │
└──────────────────────────────┘
         ↓
    [Клик на ресторан]
         ↓
    Детальная страница
```

### Детальная страница (/restaurant-detail/:id)
```
┌──────────────────────────────┐
│  🏪 РЕСТОРАН                 │
├──────────────────────────────┤
│  🖼️ Большое фото              │
│  📝 Описание                 │
│  🍴 Меню                     │
│  💬 Отзывы                   │
│  📞 Контакты                 │
└──────────────────────────────┘
         ↓
    [Забронировать стол]
         ↓
    Страница бронирования
```

### Бронирование (/booking)
```
┌──────────────────────────────┐
│  📅 БРОНИРОВАНИЕ             │
├──────────────────────────────┤
│  🏪 Выбор ресторана          │
│  📆 Дата                     │
│  🕐 Время                    │
│  👥 Количество гостей        │
│  💬 Комментарий (опционально)│
└──────────────────────────────┘
         ↓
    [Подтвердить]
         ↓
    Личный кабинет
```

### Личный кабинет (/profile)
```
┌──────────────────────────────┐
│  👤 ПРОФИЛЬ                  │
├──────────────────────────────┤
│  📋 Вкладка: Мои бронирования│
│     • Активные               │
│     • Отмененные             │
│     • [Отменить бронирование]│
│                              │
│  💬 Вкладка: Мои отзывы      │
│     • Список отзывов         │
│     • Рейтинги               │
│                              │
│  ⭐ Вкладка: Избранное       │
└──────────────────────────────┘
```

### Админ-панель (/admin)
```
┌──────────────────────────────┐
│  🛡️ АДМИН-ПАНЕЛЬ              │
├──────────────────────────────┤
│  📊 Вкладка: Обзор           │
│     • Статистика             │
│     • Графики                │
│                              │
│  🍽️ Вкладка: Рестораны       │
│     • CRUD операции          │
│                              │
│  📅 Вкладка: Бронирования    │
│     • Все бронирования       │
│     • [Подтвердить/Отменить] │
│                              │
│  💬 Вкладка: Отзывы          │
│     • Модерация              │
│     • [Удалить]              │
│                              │
│  👥 Вкладка: Пользователи    │
│     • Управление ролями      │
└──────────────────────────────┘
```

---

## 🔑 Тестовые аккаунты

### 🛡️ Администратор
```
Email: admin@tablereserve.ru
Пароль: admin123

Доступ к:
✅ Каталогу ресторанов
✅ Бронированию
✅ Отзывам
✅ Личному кабинету
✅ АДМИН-ПАНЕЛИ 🛡️
```

### 👤 Пользователь
```
Email: user@example.com
Пароль: user123

Доступ к:
✅ Каталогу ресторанов
✅ Бронированию
✅ Отзывам
✅ Личному кабинету
❌ Админ-панели
```

### 👻 Гость (не авторизован)
```
Доступ к:
✅ Каталогу ресторанов
✅ Просмотру деталей
❌ Бронированию (попросят войти)
❌ Отзывам (попросят войти)
❌ Личному кабинету
❌ Админ-панели
```

---

## 🎯 Быстрые действия

### Войти быстро (через консоль F12)

**Как админ:**
```javascript
localStorage.setItem('tablereserve_current_user', 
  JSON.stringify({
    id: '1',
    login: 'admin',
    email: 'admin@tablereserve.ru',
    isAdmin: true
  })
);
location.reload();
```

**Как пользователь:**
```javascript
localStorage.setItem('tablereserve_current_user',
  JSON.stringify({
    id: '2',
    login: 'user',
    email: 'user@example.com',
    isAdmin: false
  })
);
location.reload();
```

**Выйти:**
```javascript
localStorage.removeItem('tablereserve_current_user');
location.reload();
```

---

## 📊 Просмотр данных

### Посмотреть всех пользователей
```javascript
const users = JSON.parse(localStorage.getItem('tablereserve_users'));
console.table(users.map(u => ({
  ID: u.id,
  Login: u.login,
  Email: u.email,
  Admin: u.isAdmin ? '✅' : '❌'
})));
```

### Посмотреть все рестораны
```javascript
const restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants'));
console.table(restaurants.map(r => ({
  Название: r.name,
  Кухня: r.cuisine,
  Рейтинг: r.rating,
  Адрес: r.location
})));
```

### Посмотреть все бронирования
```javascript
const bookings = JSON.parse(localStorage.getItem('tablereserve_bookings'));
console.table(bookings.map(b => ({
  ID: b.id,
  Гости: b.guests,
  Дата: new Date(b.bookingDate).toLocaleString('ru-RU'),
  Статус: b.status
})));
```

### Полная статистика
```javascript
console.log('📊 СТАТИСТИКА TABLERESERVE\n');
console.table({
  'Пользователей': JSON.parse(localStorage.getItem('tablereserve_users')).length,
  'Ресторанов': JSON.parse(localStorage.getItem('tablereserve_restaurants')).length,
  'Бронирований': JSON.parse(localStorage.getItem('tablereserve_bookings')).length,
  'Отзывов': JSON.parse(localStorage.getItem('tablereserve_feedbacks')).length
});
```

---

## 🛠️ Полезные команды

### Создать тестовое бронирование
```javascript
const bookings = JSON.parse(localStorage.getItem('tablereserve_bookings'));
const restaurants = JSON.parse(localStorage.getItem('tablereserve_restaurants'));
const tomorrow = new Date(Date.now() + 86400000);

bookings.push({
  id: Date.now().toString(),
  userId: '2',
  restaurantId: restaurants[0].id,
  guests: 4,
  bookingDate: tomorrow.toISOString(),
  status: 'created',
  createdAt: new Date().toISOString()
});

localStorage.setItem('tablereserve_bookings', JSON.stringify(bookings));
location.reload();
```

### Сбросить все данные
```javascript
if (confirm('Удалить ВСЕ данные?')) {
  localStorage.clear();
  location.reload();
}
```

---

## 🚨 Решение проблем

### ❓ Как понять, что система работает?
```javascript
console.log('БД готова:', 
  localStorage.getItem('tablereserve_initialized') === 'true' ? '✅' : '❌'
);
```

### ❓ Не могу войти
```javascript
// Посмотрите пароли
const users = JSON.parse(localStorage.getItem('tablereserve_users'));
console.table(users.map(u => ({ 
  Email: u.email, 
  Password: u.password 
})));
```

### ❓ Админ-панель не открывается
```javascript
// Проверьте текущего пользователя
const current = JSON.parse(localStorage.getItem('tablereserve_current_user'));
console.log('Админ?', current?.isAdmin ? '✅ Да' : '❌ Нет');
```

### ❓ Пустая база данных
```javascript
localStorage.clear();
location.reload();
// БД переинициализируется автоматически
```

---

## 📚 Рекомендуемый порядок изучения

### Новичок (первый раз)
```
1. START_HERE.md          (быстрый старт)
   ↓
2. Протестировать сайт    (практика)
   ↓
3. PROJECT_SUMMARY.md     (что реализовано)
   ↓
4. README.md              (полная документация)
```

### Разработчик (изучение кода)
```
1. PROJECT_SUMMARY.md     (архитектура)
   ↓
2. /api/database.ts       (как работает БД)
   ↓
3. /services/*            (бизнес-логика)
   ↓
4. /pages/*               (UI компоненты)
```

### Проверяющий (сдача проекта)
```
1. LAUNCH_INSTRUCTIONS.md (инструкция)
   ↓
2. CHECKLIST.md           (чек-лист)
   ↓
3. Тестирование           (практика)
   ↓
4. QUICK_START_CODE.md    (код для тестов)
```

---

## 🎓 Что дальше?

После изучения документации:

1. ✅ Откройте сайт
2. ✅ Войдите как пользователь
3. ✅ Создайте бронирование
4. ✅ Войдите как админ
5. ✅ Откройте админ-панель
6. ✅ Протестируйте все функции

**Готово? Проект работает! 🎉**

---

## 📞 Нужна помощь?

Выберите подходящий файл:

| Вопрос | Файл |
|--------|------|
| Как запустить? | START_HERE.md |
| Как протестировать? | QUICK_START_CODE.md |
| Как работает система? | README.md |
| Что реализовано? | PROJECT_SUMMARY.md |
| Готов к сдаче? | CHECKLIST.md |
| Как сдать проект? | LAUNCH_INSTRUCTIONS.md |

---

**Счастливого использования TableReserve! 🍽️**

Дата: 17 декабря 2025  
Версия: 1.0.0
