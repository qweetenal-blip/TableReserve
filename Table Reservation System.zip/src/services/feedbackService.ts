/**
 * Сервис для работы с отзывами
 */

import { Feedback, User } from '../App';
import { FeedbacksAPI } from '../api/database';
import { hasPermission, Permission } from '../api/permissions';

export interface CreateFeedbackData {
  name: string;
  email: string;
  message: string;
  restaurantId?: string;
  rating?: number;
}

export const feedbackService = {
  /**
   * Получить все отзывы
   */
  getAll(): Feedback[] {
    return FeedbacksAPI.getAll();
  },

  /**
   * Получить отзывы для ресторана
   */
  getByRestaurantId(restaurantId: string): Feedback[] {
    return FeedbacksAPI.getByRestaurantId(restaurantId);
  },

  /**
   * Создать новый отзыв
   */
  create(user: User | null, feedbackData: CreateFeedbackData): Feedback {
    if (!user) {
      throw new Error('Необходимо войти в систему для оставления отзыва');
    }

    if (!hasPermission(user, Permission.CREATE_FEEDBACK)) {
      throw new Error('Недостаточно прав для создания отзыва');
    }

    // Валидация данных
    if (!feedbackData.name || !feedbackData.email || !feedbackData.message) {
      throw new Error('Все поля обязательны для заполнения');
    }

    if (feedbackData.message.length < 10) {
      throw new Error('Отзыв должен содержать минимум 10 символов');
    }

    if (feedbackData.rating && (feedbackData.rating < 1 || feedbackData.rating > 5)) {
      throw new Error('Оценка должна быть от 1 до 5');
    }

    return FeedbacksAPI.create(feedbackData);
  },

  /**
   * Обновить отзыв (только для админа)
   */
  update(user: User | null, id: string, updates: Partial<Feedback>): Feedback | null {
    if (!hasPermission(user, Permission.UPDATE_FEEDBACK)) {
      throw new Error('Недостаточно прав для обновления отзыва');
    }

    return FeedbacksAPI.update(id, updates);
  },

  /**
   * Удалить отзыв (только для админа)
   */
  delete(user: User | null, id: string): boolean {
    if (!hasPermission(user, Permission.DELETE_FEEDBACK)) {
      throw new Error('Недостаточно прав для удаления отзыва');
    }

    return FeedbacksAPI.delete(id);
  },

  /**
   * Получить средний рейтинг ресторана
   */
  getAverageRating(restaurantId: string): number {
    const feedbacks = FeedbacksAPI.getByRestaurantId(restaurantId);
    const ratings = feedbacks.filter(f => f.rating).map(f => f.rating!);

    if (ratings.length === 0) {
      return 0;
    }

    const sum = ratings.reduce((acc, rating) => acc + rating, 0);
    return Math.round((sum / ratings.length) * 10) / 10;
  },

  /**
   * Получить статистику по отзывам для ресторана
   */
  getRestaurantStats(restaurantId: string) {
    const feedbacks = FeedbacksAPI.getByRestaurantId(restaurantId);
    const ratings = feedbacks.filter(f => f.rating).map(f => f.rating!);

    const ratingCounts = {
      5: ratings.filter(r => r === 5).length,
      4: ratings.filter(r => r === 4).length,
      3: ratings.filter(r => r === 3).length,
      2: ratings.filter(r => r === 2).length,
      1: ratings.filter(r => r === 1).length
    };

    return {
      total: feedbacks.length,
      averageRating: this.getAverageRating(restaurantId),
      ratingCounts
    };
  }
};
