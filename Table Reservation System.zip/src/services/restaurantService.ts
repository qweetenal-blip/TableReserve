/**
 * Сервис для работы с ресторанами
 */

import { Restaurant, User } from '../App';
import { RestaurantsAPI } from '../api/database';
import { hasPermission, Permission } from '../api/permissions';

export const restaurantService = {
  /**
   * Получить все рестораны
   */
  getAll(): Restaurant[] {
    return RestaurantsAPI.getAll();
  },

  /**
   * Получить ресторан по ID
   */
  getById(id: string): Restaurant | null {
    return RestaurantsAPI.getById(id);
  },

  /**
   * Создать новый ресторан (только для админа)
   */
  create(user: User | null, restaurantData: Omit<Restaurant, 'id'>): Restaurant {
    if (!hasPermission(user, Permission.CREATE_RESTAURANT)) {
      throw new Error('Недостаточно прав для создания ресторана');
    }

    return RestaurantsAPI.create(restaurantData);
  },

  /**
   * Обновить ресторан (только для админа)
   */
  update(user: User | null, id: string, updates: Partial<Restaurant>): Restaurant | null {
    if (!hasPermission(user, Permission.UPDATE_RESTAURANT)) {
      throw new Error('Недостаточно прав для обновления ресторана');
    }

    return RestaurantsAPI.update(id, updates);
  },

  /**
   * Удалить ресторан (только для админа)
   */
  delete(user: User | null, id: string): boolean {
    if (!hasPermission(user, Permission.DELETE_RESTAURANT)) {
      throw new Error('Недостаточно прав для удаления ресторана');
    }

    return RestaurantsAPI.delete(id);
  },

  /**
   * Поиск ресторанов
   */
  search(query: string): Restaurant[] {
    return RestaurantsAPI.search(query);
  },

  /**
   * Фильтрация ресторанов
   */
  filter(options: {
    cuisine?: string;
    minRating?: number;
    minCapacity?: number;
  }): Restaurant[] {
    let restaurants = RestaurantsAPI.getAll();

    if (options.cuisine) {
      restaurants = restaurants.filter(r => r.cuisine === options.cuisine);
    }

    if (options.minRating) {
      restaurants = restaurants.filter(r => r.rating >= options.minRating);
    }

    if (options.minCapacity) {
      restaurants = restaurants.filter(r => r.capacity >= options.minCapacity);
    }

    return restaurants;
  },

  /**
   * Получить уникальные типы кухонь
   */
  getCuisines(): string[] {
    const restaurants = RestaurantsAPI.getAll();
    const cuisines = restaurants.map(r => r.cuisine);
    return Array.from(new Set(cuisines)).sort();
  }
};
