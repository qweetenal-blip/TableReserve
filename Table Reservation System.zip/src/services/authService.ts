/**
 * Сервис аутентификации с валидацией и обработкой ошибок
 */

import { User } from '../App';
import { AuthAPI } from '../api/database';

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  login: string;
  email: string;
  password: string;
  confirmPassword: string;
}

export interface AuthResponse {
  success: boolean;
  user?: User;
  error?: string;
}

/**
 * Валидация email
 */
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Валидация пароля
 */
function validatePassword(password: string): { valid: boolean; error?: string } {
  if (password.length < 6) {
    return { valid: false, error: 'Пароль должен содержать минимум 6 символов' };
  }
  return { valid: true };
}

/**
 * Сервис аутентификации
 */
export const authService = {
  /**
   * Вход в систему
   */
  login(credentials: LoginCredentials): AuthResponse {
    try {
      // Валидация
      if (!credentials.email || !credentials.password) {
        return {
          success: false,
          error: 'Email и пароль обязательны для заполнения'
        };
      }

      if (!validateEmail(credentials.email)) {
        return {
          success: false,
          error: 'Некорректный формат email'
        };
      }

      // Аутентификация
      const user = AuthAPI.login(credentials.email, credentials.password);

      if (!user) {
        return {
          success: false,
          error: 'Неверный email или пароль'
        };
      }

      return {
        success: true,
        user
      };
    } catch (error) {
      return {
        success: false,
        error: 'Произошла ошибка при входе в систему'
      };
    }
  },

  /**
   * Регистрация
   */
  register(data: RegisterData): AuthResponse {
    try {
      // Валидация
      if (!data.login || !data.email || !data.password || !data.confirmPassword) {
        return {
          success: false,
          error: 'Все поля обязательны для заполнения'
        };
      }

      if (data.login.length < 3) {
        return {
          success: false,
          error: 'Логин должен содержать минимум 3 символа'
        };
      }

      if (!validateEmail(data.email)) {
        return {
          success: false,
          error: 'Некорректный формат email'
        };
      }

      const passwordValidation = validatePassword(data.password);
      if (!passwordValidation.valid) {
        return {
          success: false,
          error: passwordValidation.error
        };
      }

      if (data.password !== data.confirmPassword) {
        return {
          success: false,
          error: 'Пароли не совпадают'
        };
      }

      // Регистрация
      const user = AuthAPI.register({
        login: data.login,
        email: data.email,
        password: data.password
      });

      return {
        success: true,
        user
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Произошла ошибка при регистрации'
      };
    }
  },

  /**
   * Выход из системы
   */
  logout(): void {
    AuthAPI.logout();
  },

  /**
   * Получить текущего пользователя
   */
  getCurrentUser(): User | null {
    return AuthAPI.getCurrentUser();
  },

  /**
   * Проверить, авторизован ли пользователь
   */
  isAuthenticated(): boolean {
    return AuthAPI.getCurrentUser() !== null;
  },

  /**
   * Проверить, является ли пользователь администратором
   */
  isAdmin(): boolean {
    const user = AuthAPI.getCurrentUser();
    return user?.isAdmin || false;
  }
};
