/**
 * Сервис для работы с бронированиями
 */

import { Booking, User } from '../App';
import { BookingsAPI } from '../api/database';
import { hasPermission, Permission } from '../api/permissions';

export interface CreateBookingData {
  restaurantId: string;
  guests: number;
  bookingDate: string;
}

export const bookingService = {
  /**
   * Получить все бронирования (только для админа)
   */
  getAll(user: User | null): Booking[] {
    if (!hasPermission(user, Permission.VIEW_ALL_BOOKINGS)) {
      throw new Error('Недостаточно прав для просмотра всех бронирований');
    }

    return BookingsAPI.getAll();
  },

  /**
   * Получить бронирования текущего пользователя
   */
  getUserBookings(user: User | null): Booking[] {
    if (!user) {
      throw new Error('Необходимо войти в систему');
    }

    if (!hasPermission(user, Permission.VIEW_OWN_BOOKINGS)) {
      throw new Error('Недостаточно прав для просмотра бронирований');
    }

    return BookingsAPI.getByUserId(user.id);
  },

  /**
   * Получить бронирования для ресторана
   */
  getRestaurantBookings(restaurantId: string): Booking[] {
    return BookingsAPI.getByRestaurantId(restaurantId);
  },

  /**
   * Создать новое бронирование
   */
  create(user: User | null, bookingData: CreateBookingData): Booking {
    if (!user) {
      throw new Error('Необходимо войти в систему для создания бронирования');
    }

    if (!hasPermission(user, Permission.CREATE_BOOKING)) {
      throw new Error('Недостаточно прав для создания бронирования');
    }

    // Валидация данных
    if (!bookingData.restaurantId) {
      throw new Error('Не указан ресторан');
    }

    if (bookingData.guests < 1 || bookingData.guests > 20) {
      throw new Error('Количество гостей должно быть от 1 до 20');
    }

    const bookingDate = new Date(bookingData.bookingDate);
    const now = new Date();

    if (bookingDate < now) {
      throw new Error('Нельзя забронировать на прошедшую дату');
    }

    // Создание бронирования
    return BookingsAPI.create({
      userId: user.id,
      restaurantId: bookingData.restaurantId,
      guests: bookingData.guests,
      bookingDate: bookingData.bookingDate
    });
  },

  /**
   * Обновить статус бронирования
   */
  updateStatus(user: User | null, id: string, status: Booking['status']): Booking | null {
    if (!user) {
      throw new Error('Необходимо войти в систему');
    }

    const booking = BookingsAPI.getAll().find(b => b.id === id);
    
    if (!booking) {
      throw new Error('Бронирование не найдено');
    }

    // Проверка прав
    const isOwner = booking.userId === user.id;
    const canUpdateOwn = isOwner && hasPermission(user, Permission.UPDATE_OWN_BOOKING);
    const canUpdateAll = hasPermission(user, Permission.UPDATE_ALL_BOOKINGS);

    if (!canUpdateOwn && !canUpdateAll) {
      throw new Error('Недостаточно прав для обновления бронирования');
    }

    return BookingsAPI.update(id, { status });
  },

  /**
   * Отменить бронирование
   */
  cancel(user: User | null, id: string): Booking | null {
    if (!user) {
      throw new Error('Необходимо войти в систему');
    }

    const booking = BookingsAPI.getAll().find(b => b.id === id);
    
    if (!booking) {
      throw new Error('Бронирование не найдено');
    }

    // Проверка прав
    const isOwner = booking.userId === user.id;
    const canCancelOwn = isOwner && hasPermission(user, Permission.CANCEL_OWN_BOOKING);
    const canCancelAll = hasPermission(user, Permission.CANCEL_ALL_BOOKINGS);

    if (!canCancelOwn && !canCancelAll) {
      throw new Error('Недостаточно прав для отмены бронирования');
    }

    return BookingsAPI.cancel(id);
  },

  /**
   * Удалить бронирование (только для админа)
   */
  delete(user: User | null, id: string): boolean {
    if (!hasPermission(user, Permission.DELETE_BOOKING)) {
      throw new Error('Недостаточно прав для удаления бронирования');
    }

    return BookingsAPI.delete(id);
  },

  /**
   * Получить статистику по бронированиям
   */
  getStats(user: User | null) {
    if (!user) {
      return null;
    }

    const bookings = hasPermission(user, Permission.VIEW_ALL_BOOKINGS)
      ? BookingsAPI.getAll()
      : BookingsAPI.getByUserId(user.id);

    return {
      total: bookings.length,
      active: bookings.filter(b => b.status === 'confirmed').length,
      pending: bookings.filter(b => b.status === 'created').length,
      cancelled: bookings.filter(b => b.status === 'cancelled').length
    };
  }
};
