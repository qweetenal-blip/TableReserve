/**
 * Сервис для административных функций
 */

import { User } from '../App';
import { UsersAPI, AnalyticsAPI } from '../api/database';
import { hasPermission, Permission } from '../api/permissions';

export const adminService = {
  /**
   * Получить всех пользователей (только для админа)
   */
  getAllUsers(user: User | null): User[] {
    if (!hasPermission(user, Permission.VIEW_USERS)) {
      throw new Error('Недостаточно прав для просмотра пользователей');
    }

    return UsersAPI.getAll();
  },

  /**
   * Получить пользователя по ID (только для админа)
   */
  getUserById(user: User | null, id: string): User | null {
    if (!hasPermission(user, Permission.VIEW_USERS)) {
      throw new Error('Недостаточно прав для просмотра пользователей');
    }

    return UsersAPI.getById(id);
  },

  /**
   * Обновить пользователя (только для админа)
   */
  updateUser(user: User | null, id: string, updates: Partial<User>): User | null {
    if (!hasPermission(user, Permission.UPDATE_USER)) {
      throw new Error('Недостаточно прав для обновления пользователей');
    }

    return UsersAPI.update(id, updates);
  },

  /**
   * Удалить пользователя (только для админа)
   */
  deleteUser(user: User | null, id: string): boolean {
    if (!hasPermission(user, Permission.DELETE_USER)) {
      throw new Error('Недостаточно прав для удаления пользователей');
    }

    return UsersAPI.delete(id);
  },

  /**
   * Получить общую статистику (только для админа)
   */
  getStats(user: User | null) {
    if (!hasPermission(user, Permission.VIEW_ANALYTICS)) {
      throw new Error('Недостаточно прав для просмотра аналитики');
    }

    return AnalyticsAPI.getStats();
  },

  /**
   * Получить последние действия (только для админа)
   */
  getRecentActivity(user: User | null, limit: number = 10) {
    if (!hasPermission(user, Permission.VIEW_ANALYTICS)) {
      throw new Error('Недостаточно прав для просмотра аналитики');
    }

    return AnalyticsAPI.getRecentActivity(limit);
  },

  /**
   * Изменить роль пользователя (только для админа)
   */
  changeUserRole(user: User | null, userId: string, isAdmin: boolean): User | null {
    if (!hasPermission(user, Permission.UPDATE_USER)) {
      throw new Error('Недостаточно прав для изменения ролей');
    }

    return UsersAPI.update(userId, { isAdmin });
  },

  /**
   * Сбросить пароль пользователя (только для админа)
   */
  resetUserPassword(user: User | null, userId: string, newPassword: string): boolean {
    if (!hasPermission(user, Permission.UPDATE_USER)) {
      throw new Error('Недостаточно прав для сброса пароля');
    }

    // В реальном приложении здесь будет хеширование пароля
    const users = JSON.parse(localStorage.getItem('tablereserve_users') || '[]');
    const userIndex = users.findIndex((u: any) => u.id === userId);

    if (userIndex !== -1) {
      users[userIndex].password = newPassword;
      localStorage.setItem('tablereserve_users', JSON.stringify(users));
      return true;
    }

    return false;
  }
};
