import { Restaurant, Booking, Feedback, User } from '../App';

export const mockRestaurants: Restaurant[] = [
  {
    id: '1',
    name: 'La Bella Italia',
    description: 'Аутентичный итальянский ресторан с традиционной кухней и уютной атмосферой',
    menu: 'Паста карбонара, Пицца Маргарита, Ризотто с морепродуктами, Тирамису',
    image: 'https://images.unsplash.com/photo-1723608334799-e6398469cb04?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpdGFsaWFuJTIwcmVzdGF1cmFudCUyMGZvb2R8ZW58MXx8fHwxNzY1NzE4NjU0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'ул. Пушкина, 10',
    capacity: 50,
    rating: 4.8,
    cuisine: 'Итальянская'
  },
  {
    id: '2',
    name: 'Coffee Dreams',
    description: 'Современная кофейня с авторскими десертами и специальными напитками',
    menu: 'Капучино, Латте, Флэт уайт, Круассаны, Чизкейк, Макаронс',
    image: 'https://images.unsplash.com/photo-1736813561668-cb3d783913b8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBjYWZlJTIwY29mZmVlfGVufDF8fHx8MTc2NTY5Mjc2NXww&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'пр. Ленина, 25',
    capacity: 30,
    rating: 4.6,
    cuisine: 'Кофейня'
  },
  {
    id: '3',
    name: 'Sakura Sushi',
    description: 'Японский ресторан с свежайшими суши и роллами от шеф-повара из Токио',
    menu: 'Суши сет, Роллы Филадельфия, Сашими, Рамен, Мисо суп',
    image: 'https://images.unsplash.com/photo-1725122194872-ace87e5a1a8d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMHN1c2hpJTIwcmVzdGF1cmFudHxlbnwxfHx8fDE3NjU3ODM2MTd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'ул. Гагарина, 5',
    capacity: 40,
    rating: 4.9,
    cuisine: 'Японская'
  },
  {
    id: '4',
    name: 'Prime Steakhouse',
    description: 'Премиальный стейк-хаус с мясом высшего качества и винной картой',
    menu: 'Рибай стейк, Филе миньон, Томагавк, Картофель по-деревенски',
    image: 'https://images.unsplash.com/photo-1690983325563-fe4412c4c347?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGVha2hvdXNlJTIwbWVhdCUyMGdyaWxsfGVufDF8fHx8MTc2NTc5MDAzNHww&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'ул. Мира, 15',
    capacity: 60,
    rating: 4.7,
    cuisine: 'Стейк-хаус'
  },
  {
    id: '5',
    name: 'Le Gourmet',
    description: 'Изысканный французский ресторан с высокой кухней и элегантной обстановкой',
    menu: 'Фуа-гра, Буйабес, Конфи из утки, Крем-брюле',
    image: 'https://images.unsplash.com/photo-1756397481872-ed981ef72a51?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwcmVzdGF1cmFudCUyMGludGVyaW9yfGVufDF8fHx8MTc2NTc1MjM3NXww&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'Невский пр., 100',
    capacity: 45,
    rating: 4.9,
    cuisine: 'Французская'
  },
  {
    id: '6',
    name: 'Garden Terrace',
    description: 'Ресторан с летней террасой, средиземноморская кухня и живая музыка',
    menu: 'Греческий салат, Морепродукты на гриле, Паэлья, Брускетты',
    image: 'https://images.unsplash.com/photo-1651209315802-12190ccfee26?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaW5lJTIwZGluaW5nJTIwdGFibGV8ZW58MXx8fHwxNzY1NzEyMTAxfDA&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'Парковая ул., 7',
    capacity: 70,
    rating: 4.5,
    cuisine: 'Средиземноморская'
  }
];

export const mockUsers: User[] = [
  {
    id: '1',
    login: 'admin',
    email: 'admin@tablereserve.ru',
    isAdmin: true
  },
  {
    id: '2',
    login: 'user',
    email: 'user@example.com',
    isAdmin: false
  }
];

export const mockBookings: Booking[] = [
  {
    id: '1',
    userId: '2',
    restaurantId: '1',
    guests: 4,
    bookingDate: '2025-12-20T19:00:00',
    status: 'confirmed',
    createdAt: '2025-12-15T10:30:00'
  },
  {
    id: '2',
    userId: '2',
    restaurantId: '3',
    guests: 2,
    bookingDate: '2025-12-22T20:00:00',
    status: 'created',
    createdAt: '2025-12-15T14:20:00'
  }
];

export const mockFeedbacks: Feedback[] = [
  {
    id: '1',
    name: 'Анна Иванова',
    email: 'anna@example.com',
    message: 'Отличный ресторан! Прекрасная атмосфера и вкусная еда.',
    restaurantId: '1',
    rating: 5,
    createdAt: '2025-12-10T18:00:00'
  },
  {
    id: '2',
    name: 'Петр Сидоров',
    email: 'petr@example.com',
    message: 'Замечательные суши, обязательно вернемся!',
    restaurantId: '3',
    rating: 5,
    createdAt: '2025-12-12T20:30:00'
  }
];
