import React from 'react';
import { MapPin, Users, Star } from './Icons';
import type { Restaurant } from '../App';
import { ImageWithFallback } from './figma/ImageWithFallback';

type RestaurantCardProps = {
  restaurant: Restaurant;
  onViewDetails: () => void;
  onBook: () => void;
};

export function RestaurantCard({ restaurant, onViewDetails, onBook }: RestaurantCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
      <div className="relative h-48 overflow-hidden">
        <ImageWithFallback 
          src={restaurant.image}
          alt={restaurant.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full flex items-center gap-1">
          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
          <span>{restaurant.rating}</span>
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex items-start justify-between mb-2">
          <h3 className="text-gray-900">{restaurant.name}</h3>
          <span className="text-xs bg-orange-100 text-orange-600 px-2 py-1 rounded">
            {restaurant.cuisine}
          </span>
        </div>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
          {restaurant.description}
        </p>

        <div className="flex items-center gap-4 mb-4 text-sm text-gray-500">
          <div className="flex items-center gap-1">
            <MapPin className="w-4 h-4" />
            <span>{restaurant.location}</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="w-4 h-4" />
            <span>До {restaurant.capacity} мест</span>
          </div>
        </div>

        <div className="flex gap-3">
          <button
            onClick={onViewDetails}
            className="flex-1 px-4 py-2 border border-orange-500 text-orange-500 rounded-lg hover:bg-orange-50 transition-colors"
          >
            Подробнее
          </button>
          <button
            onClick={onBook}
            className="flex-1 px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
          >
            Забронировать
          </button>
        </div>
      </div>
    </div>
  );
}