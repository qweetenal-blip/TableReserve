import React from 'react';
import { MapPin, Phone, Mail } from './Icons';

type FooterProps = {
  navigateTo: (page: string) => void;
};

export function Footer({ navigateTo }: FooterProps) {
  return (
    <footer className="bg-gray-900 text-white mt-16">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* О компании */}
          <div>
            <h3 className="mb-4">TableReserve</h3>
            <p className="text-gray-400 text-sm">
              Сервис бронирования столов в лучших ресторанах города. Удобно, быстро, надежно.
            </p>
          </div>

          {/* Навигация */}
          <div>
            <h4 className="mb-4">Навигация</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button 
                  onClick={() => navigateTo('main')}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Главная
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateTo('restaurants')}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Рестораны
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateTo('help')}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Контакты
                </button>
              </li>
              <li>
                <button 
                  onClick={() => navigateTo('profile')}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Личный кабинет
                </button>
              </li>
            </ul>
          </div>

          {/* Контакты */}
          <div>
            <h4 className="mb-4">Контакты</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2 text-gray-400">
                <Phone className="w-4 h-4" />
                +7 (800) 123-45-67
              </li>
              <li className="flex items-center gap-2 text-gray-400">
                <Mail className="w-4 h-4" />
                info@tablereserve.ru
              </li>
              <li className="flex items-center gap-2 text-gray-400">
                <MapPin className="w-4 h-4" />
                Москва, ул. Примерная, 1
              </li>
            </ul>
          </div>

          {/* Социальные сети */}
          <div>
            <h4 className="mb-4">Мы в соцсетях</h4>
            <div className="flex gap-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                VK
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                Instagram
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                Telegram
              </a>
            </div>
          </div>
        </div>

        {/* Нижняя часть */}
        <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-gray-400">
          <p>© 2025 TableReserve. Все права защищены.</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <button className="hover:text-white transition-colors">
              Политика конфиденциальности
            </button>
            <button className="hover:text-white transition-colors">
              Условия использования
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}