import React from 'react';
import { User, LogIn, LogOut, UserCircle, Shield } from './Icons';
import type { User as UserType } from '../App';

type HeaderProps = {
  currentUser: UserType | null;
  navigateTo: (page: string) => void;
  onLogout: () => void;
};

export function Header({ currentUser, navigateTo, onLogout }: HeaderProps) {
  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      {/* Верхнее меню с контактами */}
      <div className="bg-gray-800 text-white">
        <div className="container mx-auto px-4 py-2 flex justify-between items-center">
          <div className="flex gap-6">
            <span>📞 +7 (800) 123-45-67</span>
            <span>📧 info@tablereserve.ru</span>
          </div>
          <div className="flex gap-4">
            <a href="#" className="hover:text-gray-300">VK</a>
            <a href="#" className="hover:text-gray-300">Instagram</a>
            <a href="#" className="hover:text-gray-300">Telegram</a>
          </div>
        </div>
      </div>

      {/* Основная навигация */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          {/* Логотип */}
          <button 
            onClick={() => navigateTo('main')}
            className="flex items-center gap-2 hover:opacity-80 transition-opacity"
          >
            <div className="bg-orange-500 text-white p-2 rounded-lg">
              <User className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-orange-500">TableReserve</h1>
              <p className="text-xs text-gray-600">Бронирование столов</p>
            </div>
          </button>

          {/* Навигация */}
          <nav className="flex items-center gap-6">
            <button 
              onClick={() => navigateTo('restaurants')}
              className="text-gray-700 hover:text-orange-500 transition-colors"
            >
              Рестораны
            </button>
            <button 
              onClick={() => navigateTo('main')}
              className="text-gray-700 hover:text-orange-500 transition-colors"
            >
              Предложения
            </button>
            <button 
              onClick={() => navigateTo('help')}
              className="text-gray-700 hover:text-orange-500 transition-colors"
            >
              Контакты
            </button>

            {/* Личный кабинет / Вход */}
            {currentUser ? (
              <div className="flex items-center gap-4">
                {currentUser.isAdmin && (
                  <button
                    onClick={() => navigateTo('admin')}
                    className="flex items-center gap-2 text-purple-600 hover:text-purple-700"
                  >
                    <Shield className="w-5 h-5" />
                    Админ
                  </button>
                )}
                <button
                  onClick={() => navigateTo('profile')}
                  className="flex items-center gap-2 text-gray-700 hover:text-orange-500"
                >
                  <UserCircle className="w-5 h-5" />
                  {currentUser.login}
                </button>
                <button
                  onClick={onLogout}
                  className="flex items-center gap-2 text-gray-700 hover:text-red-500"
                >
                  <LogOut className="w-5 h-5" />
                  Выход
                </button>
              </div>
            ) : (
              <button
                onClick={() => navigateTo('login')}
                className="flex items-center gap-2 bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600 transition-colors"
              >
                <LogIn className="w-5 h-5" />
                Войти
              </button>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
}